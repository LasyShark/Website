import FaqHero from "@/components/faq/faq-hero"
import FaqContent from "@/components/faq/faq-content"
import StillNeedHelp from "@/components/faq/still-need-help"
import { faqData } from "@/lib/faq-data"

export const metadata = {
  title: "FAQ - The Cellar Guild",
  description: "Find answers to common questions about our products, shipping, returns, and more.",
}

export default function FaqPage() {
  return (
    <div className="min-h-screen bg-white text-gray-800 font-sans tracking-normal">
      <FaqHero />
      <FaqContent faqData={faqData} />
      <StillNeedHelp />
    </div>
  )
}
