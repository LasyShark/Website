"use client"

import type { FaqItem } from "@/lib/faq-data"
import { ChevronDown, ChevronUp } from "lucide-react"

interface FaqAccordionProps {
  questions: FaqItem[]
  expandedQuestions: Record<string, boolean>
  toggleQuestion: (id: string) => void
}

export default function FaqAccordion({ questions, expandedQuestions, toggleQuestion }: FaqAccordionProps) {
  return (
    <div className="space-y-4">
      {questions.map((item) => (
        <div
          key={item.id}
          className={`border border-gray-200 rounded-sm overflow-hidden transition-all duration-300 ${
            expandedQuestions[item.id] ? "shadow-md" : ""
          }`}
        >
          <button
            onClick={() => toggleQuestion(item.id)}
            className="w-full px-6 py-4 text-left flex justify-between items-center hover:bg-gray-50"
            aria-expanded={expandedQuestions[item.id]}
            aria-controls={`content-${item.id}`}
          >
            <span className="font-medium text-base font-sans text-gray-800">{item.question}</span>
            {expandedQuestions[item.id] ? (
              <ChevronUp className="text-amber-700 h-5 w-5" />
            ) : (
              <ChevronDown className="text-amber-700 h-5 w-5" />
            )}
          </button>
          <div
            id={`content-${item.id}`}
            className={`px-6 overflow-hidden transition-all duration-300 ${
              expandedQuestions[item.id] ? "max-h-96 py-4" : "max-h-0"
            }`}
          >
            <p className="text-gray-600 text-base font-sans">{item.answer}</p>
          </div>
        </div>
      ))}
    </div>
  )
}
