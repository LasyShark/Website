"use client"

import { useState, useRef } from "react"
import type { FaqData } from "@/lib/faq-data"
import FaqAccordion from "./faq-accordion"
import { Search, X } from "lucide-react"

interface FaqContentProps {
  faqData: FaqData
}

export default function FaqContent({ faqData }: FaqContentProps) {
  const [activeCategory, setActiveCategory] = useState("shipping")
  const [searchQuery, setSearchQuery] = useState("")
  const [expandedQuestions, setExpandedQuestions] = useState<Record<string, boolean>>({})

  const faqSections = useRef<Record<string, HTMLDivElement | null>>({
    shipping: null,
    returns: null,
    products: null,
    ordering: null,
    account: null,
    general: null,
  })

  const scrollToSection = (category: string) => {
    setActiveCategory(category)
    faqSections.current[category]?.scrollIntoView({ behavior: "smooth", block: "start" })
  }

  const toggleQuestion = (id: string) => {
    setExpandedQuestions((prev) => ({
      ...prev,
      [id]: !prev[id],
    }))
  }

  const filteredFaqs = Object.entries(faqData).reduce(
    (acc, [category, questions]) => {
      const filteredQuestions = questions.filter(
        (q) =>
          q.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
          q.answer.toLowerCase().includes(searchQuery.toLowerCase()),
      )
      if (filteredQuestions.length > 0) {
        acc[category] = filteredQuestions
      }
      return acc
    },
    {} as Record<string, typeof faqData.shipping>,
  )

  return (
    <section className="py-12 max-w-4xl mx-auto px-6">
      {/* Search Bar */}
      <div className="mb-12">
        <div className="relative">
          <input
            type="text"
            placeholder="Search for answers..."
            className="w-full px-4 py-3 pl-12 border-2 border-gray-300 focus:border-amber-700 outline-none rounded-sm text-lg font-sans text-gray-800"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            aria-label="Search FAQs"
          />
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          {searchQuery && (
            <button
              className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              onClick={() => setSearchQuery("")}
              aria-label="Clear search"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <p className="text-xs font-sans text-gray-500 mt-2 ml-1">Type keywords to find answers to your questions</p>
      </div>

      {/* Category Navigation */}
      <div className="mb-12 overflow-x-auto scrollbar-hide">
        <div className="flex space-x-4 min-w-max">
          {Object.keys(faqData).map((category) => (
            <button
              key={category}
              onClick={() => scrollToSection(category)}
              className={`px-6 py-3 font-medium rounded-sm transition-all duration-300 whitespace-nowrap text-lg font-serif ${
                activeCategory === category ? "bg-amber-700 text-white" : "bg-gray-100 text-gray-500 hover:bg-gray-200"
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* FAQ Accordion Sections */}
      {searchQuery === "" ? (
        Object.entries(faqData).map(([category, questions]) => (
          <div key={category} ref={(el) => (faqSections.current[category] = el)} className="mb-12">
            <h2 className="text-3xl font-serif font-bold mb-6 pb-2 border-b-2 border-amber-700 tracking-tight text-gray-800">
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </h2>
            <FaqAccordion questions={questions} expandedQuestions={expandedQuestions} toggleQuestion={toggleQuestion} />
          </div>
        ))
      ) : Object.keys(filteredFaqs).length > 0 ? (
        Object.entries(filteredFaqs).map(([category, questions]) => (
          <div key={category} className="mb-12">
            <h2 className="text-3xl font-serif font-bold mb-6 pb-2 border-b-2 border-amber-700 tracking-tight text-gray-800">
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </h2>
            <FaqAccordion questions={questions} expandedQuestions={expandedQuestions} toggleQuestion={toggleQuestion} />
          </div>
        ))
      ) : (
        <div className="text-center py-12">
          <Search className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <p className="text-gray-800 text-lg font-sans">No results found for "{searchQuery}"</p>
          <p className="text-gray-500 mt-2 text-sm font-sans">Try using different keywords or browse categories</p>
          <button
            onClick={() => setSearchQuery("")}
            className="mt-6 bg-amber-700 hover:bg-amber-800 text-white px-6 py-2 rounded-sm transition-all duration-300 text-base font-sans"
          >
            Clear Search
          </button>
        </div>
      )}
    </section>
  )
}
