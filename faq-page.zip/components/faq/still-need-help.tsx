import Link from "next/link"
import { Mail, Phone, MessageSquare } from "lucide-react"

export default function StillNeedHelp() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <h2 className="text-3xl font-serif font-bold mb-6 tracking-tight text-gray-800">Still Need Help?</h2>
        <p className="text-gray-600 mb-8 max-w-2xl mx-auto text-base font-sans">
          If you couldn't find the answer you were looking for, our customer service team is here to help.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white p-6 rounded-sm shadow-sm hover:shadow-md transition-shadow duration-300">
            <div className="text-amber-700 text-3xl mb-4">
              <Mail className="mx-auto h-8 w-8" />
            </div>
            <h3 className="text-xl font-serif font-medium mb-2 text-gray-800">Email Us</h3>
            <p className="text-gray-600 mb-4 text-base font-sans">
              Send us a message and we'll respond within 24 hours.
            </p>
            <a
              href="mailto:hello@cellarguild.com"
              className="text-amber-700 hover:text-amber-800 font-medium text-base font-sans"
            >
              hello@cellarguild.com
            </a>
          </div>
          <div className="bg-white p-6 rounded-sm shadow-sm hover:shadow-md transition-shadow duration-300">
            <div className="text-amber-700 text-3xl mb-4">
              <Phone className="mx-auto h-8 w-8" />
            </div>
            <h3 className="text-xl font-serif font-medium mb-2 text-gray-800">Call Us</h3>
            <p className="text-gray-600 mb-4 text-base font-sans">Available Monday-Friday, 9am-5pm EST.</p>
            <a href="tel:+12345678910" className="text-amber-700 hover:text-amber-800 font-medium text-base font-sans">
              +1 (234) 567-8910
            </a>
          </div>
          <div className="bg-white p-6 rounded-sm shadow-sm hover:shadow-md transition-shadow duration-300">
            <div className="text-amber-700 text-3xl mb-4">
              <MessageSquare className="mx-auto h-8 w-8" />
            </div>
            <h3 className="text-xl font-serif font-medium mb-2 text-gray-800">Live Chat</h3>
            <p className="text-gray-600 mb-4 text-base font-sans">Chat with our support team in real-time.</p>
            <button className="text-amber-700 hover:text-amber-800 font-medium text-base font-sans">Start Chat</button>
          </div>
        </div>
        <Link
          href="/"
          className="inline-block border-2 border-amber-700 text-amber-700 hover:bg-amber-700 hover:text-white px-8 py-3 rounded-sm transition-all duration-300 text-base font-sans"
        >
          Return to Home Page
        </Link>
      </div>
    </section>
  )
}
