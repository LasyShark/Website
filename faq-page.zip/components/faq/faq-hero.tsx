export default function FaqHero() {
  return (
    <section className="relative py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center">
          <h1 className="text-6xl font-serif font-bold mb-6 tracking-tight text-gray-800">
            Frequently Asked Questions
          </h1>
          <div className="w-24 h-1 bg-amber-700 mx-auto mb-8"></div>
          <p className="text-gray-600 max-w-2xl mx-auto text-base font-sans">
            Find answers to common questions about our globally sourced products from Europe, India, China, and beyond.
            We ensure the highest quality standards for all our international imports. Browse our shipping, returns, and
            product information below, or contact us for personalized assistance.
          </p>
        </div>
      </div>
    </section>
  )
}
