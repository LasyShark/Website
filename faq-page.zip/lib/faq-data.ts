export type FaqItem = {
  id: string
  question: string
  answer: string
}

export type FaqData = {
  [category: string]: FaqItem[]
}

export const faqData: FaqData = {
  shipping: [
    {
      id: "shipping-1",
      question: "How long does shipping take?",
      answer:
        "Standard shipping typically takes 3-5 business days within the continental US. International shipping can take 7-14 business days depending on the destination country and customs processing.",
    },
    {
      id: "shipping-2",
      question: "Do you ship internationally?",
      answer:
        "Yes, we ship to most countries worldwide. International shipping rates and delivery times vary by location. Please note that customers are responsible for any customs fees or import taxes that may apply.",
    },
    {
      id: "shipping-3",
      question: "How much does shipping cost?",
      answer:
        "Shipping costs are calculated based on weight, dimensions, and delivery location. Orders over $75 qualify for free standard shipping within the US. You can view exact shipping costs at checkout before completing your purchase.",
    },
    {
      id: "shipping-4",
      question: "Can I track my order?",
      answer:
        "Yes, once your order ships, you will receive a confirmation email with tracking information. You can also view your order status and tracking information in your account dashboard.",
    },
    {
      id: "shipping-5",
      question: "Do you offer expedited shipping?",
      answer:
        "Yes, we offer expedited shipping options at checkout. Expedited orders placed before 12pm EST on business days typically ship the same day. Next-day and 2-day shipping options are available for most US locations.",
    },
  ],
  returns: [
    {
      id: "returns-1",
      question: "What is your return policy?",
      answer:
        "We accept returns within 30 days of delivery for items in their original condition with tags attached. Custom or personalized items cannot be returned unless defective.",
    },
    {
      id: "returns-2",
      question: "How do I initiate a return?",
      answer:
        "To initiate a return, please log into your account and select the order containing the items you wish to return. Follow the prompts to generate a return label. You can also contact our customer service team for assistance.",
    },
    {
      id: "returns-3",
      question: "Do I have to pay for return shipping?",
      answer:
        "Return shipping costs are the responsibility of the customer unless the return is due to our error or a defective product. Return shipping labels are available at a discounted rate through your account.",
    },
    {
      id: "returns-4",
      question: "How long does it take to process a refund?",
      answer:
        "Once we receive your return, it typically takes 3-5 business days to inspect and process. Refunds are issued to the original payment method and may take an additional 2-5 business days to appear on your statement, depending on your financial institution.",
    },
    {
      id: "returns-5",
      question: "Can I exchange an item instead of returning it?",
      answer:
        'Yes, exchanges are available for items in their original condition. To request an exchange, follow the same process as a return but select "Exchange" instead of "Return" when prompted. If the exchanged item has a different price, you will be charged or refunded the difference.',
    },
  ],
  products: [
    {
      id: "products-1",
      question: "Are your products handmade?",
      answer:
        "Many of our products are handcrafted by skilled artisans. Each product description specifies whether the item is handmade, traditionally crafted, or manufactured. We prioritize authentic craftsmanship and sustainable production methods.",
    },
    {
      id: "products-2",
      question: "What materials are used in your products?",
      answer:
        "We use a variety of high-quality, sustainable materials including locally sourced wood, natural fibers, plant-based dyes, and recycled materials whenever possible. Specific material information is listed in each product description.",
    },
    {
      id: "products-3",
      question: "Do you offer gift wrapping?",
      answer:
        "Yes, we offer eco-friendly gift wrapping for an additional $5 per item. You can select this option during checkout. Gift messages can be included at no extra charge.",
    },
    {
      id: "products-4",
      question: "How should I care for my wooden items?",
      answer:
        "Wooden items should be kept away from direct sunlight and extreme temperature changes. Clean with a soft, slightly damp cloth and avoid harsh chemicals. Periodically treating wooden items with food-safe mineral oil will help maintain their beauty and longevity.",
    },
    {
      id: "products-5",
      question: "Are your dyes and materials safe?",
      answer:
        "Yes, all our dyes and materials are non-toxic and safe for their intended use. Our natural dyes are plant-based, and we avoid harmful chemicals in all our products. Specific safety information is included with each product.",
    },
  ],
  ordering: [
    {
      id: "ordering-1",
      question: "How do I place an order?",
      answer:
        "You can place an order directly through our website by adding items to your cart and proceeding to checkout. You can check out as a guest or create an account for a faster checkout experience in the future.",
    },
    {
      id: "ordering-2",
      question: "Can I modify or cancel my order?",
      answer:
        "Orders can be modified or canceled within 2 hours of placement. Please contact our customer service team immediately if you need to make changes. Once an order has entered processing, we cannot guarantee changes can be made.",
    },
    {
      id: "ordering-3",
      question: "What payment methods do you accept?",
      answer:
        "We accept all major credit cards (Visa, Mastercard, American Express, Discover), PayPal, Apple Pay, and Google Pay. All payments are securely processed and encrypted.",
    },
    {
      id: "ordering-4",
      question: "Do you offer wholesale or bulk discounts?",
      answer:
        "Yes, we offer wholesale pricing for qualified businesses and volume discounts for large orders. Please contact our sales team at wholesale@cellarguild.com for more information and to apply for a wholesale account.",
    },
    {
      id: "ordering-5",
      question: "Are there any taxes or duties?",
      answer:
        "Sales tax is collected according to local and state regulations. For international orders, customers are responsible for any customs fees, import duties, or taxes imposed by their country. These are not included in our prices or shipping costs.",
    },
  ],
  account: [
    {
      id: "account-1",
      question: "How do I create an account?",
      answer:
        'You can create an account by clicking on the "Account" icon in the top navigation bar and selecting "Create Account," or during the checkout process. You\'ll need to provide your email address and create a password.',
    },
    {
      id: "account-2",
      question: "What are the benefits of creating an account?",
      answer:
        "Account benefits include faster checkout, order tracking, order history, saved shipping addresses, wishlist functionality, and access to exclusive promotions and early product releases.",
    },
    {
      id: "account-3",
      question: "How can I reset my password?",
      answer:
        'To reset your password, click on the "Account" icon, select "Sign In," and then click "Forgot Password." You\'ll receive an email with instructions to create a new password.',
    },
    {
      id: "account-4",
      question: "Can I save multiple shipping addresses?",
      answer:
        "Yes, you can save multiple shipping addresses in your account settings. This makes checkout faster when sending gifts or ordering for different locations.",
    },
    {
      id: "account-5",
      question: "How do I view my order history?",
      answer:
        "Your complete order history is available in your account dashboard. You can view order details, track shipments, and initiate returns for eligible orders.",
    },
  ],
  general: [
    {
      id: "general-1",
      question: "What is The Cellar Guild?",
      answer:
        "The Cellar Guild is a curated marketplace for hobbyist materials, games, puzzles, and crafting supplies inspired by Nordic folk traditions. We work with artisans and craftspeople to bring authentic, high-quality products to enthusiasts worldwide.",
    },
    {
      id: "general-2",
      question: "Are you a sustainable company?",
      answer:
        "Sustainability is central to our mission. We prioritize eco-friendly materials, minimal packaging, carbon-neutral shipping options, and partnerships with artisans who share our commitment to environmental responsibility.",
    },
    {
      id: "general-3",
      question: "Do you have a physical store?",
      answer: "We are solely online.",
    },
    {
      id: "general-4",
      question: "How can I contact customer service?",
      answer:
        "Our customer service team is available Monday-Friday, 9am-5pm EST. You can reach us by email at hello@cellarguild.com, by phone at +1 (234) 567-8910, or through the contact form on our website.",
    },
    {
      id: "general-5",
      question: "Do you offer gift cards?",
      answer:
        "Yes, we offer digital gift cards in denominations ranging from $25 to $500. Gift cards never expire and can be used for any purchase on our website.",
    },
  ],
}
