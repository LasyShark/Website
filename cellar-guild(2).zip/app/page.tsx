import CellarGuildShop from "../cellar-guild-shop"

export default function Home() {
  return <CellarGuildShop />
}
