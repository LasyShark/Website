"use client"

interface SizeSelectorProps {
  sizes: string[]
  selectedSize: string
  setSelectedSize: (size: string) => void
  showSizeGuide: boolean
  setShowSizeGuide: (show: boolean) => void
}

export default function SizeSelector({
  sizes,
  selectedSize,
  setSelectedSize,
  showSizeGuide,
  setShowSizeGuide,
}: SizeSelectorProps) {
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-2">
        <h3 className="font-medium text-gray-900">Size</h3>
        <button
          className="text-sm text-gray-500 underline cursor-pointer"
          onClick={() => setShowSizeGuide(!showSizeGuide)}
        >
          Size guide
        </button>
      </div>
      <div className="flex space-x-3">
        {sizes.map((size) => (
          <button
            key={size}
            className={`w-12 h-12 flex items-center justify-center border rounded-md cursor-pointer ${
              selectedSize === size
                ? "bg-gray-900 text-white border-gray-900"
                : "border-gray-300 text-gray-700 hover:border-gray-900"
            }`}
            onClick={() => setSelectedSize(size)}
          >
            {size}
          </button>
        ))}
      </div>
      {showSizeGuide && (
        <div className="mt-4 p-4 bg-gray-50 rounded-md">
          <h4 className="font-medium mb-2">Size Guide</h4>
          <ul className="text-sm text-gray-600 space-y-1">
            <li>S: 3.4" x 4.3" (8.6 x 10.9 cm)</li>
            <li>M: 3.7" x 4.5" (9.4 x 11.4 cm)</li>
            <li>L: 4.0" x 4.7" (10.2 x 11.9 cm)</li>
          </ul>
        </div>
      )}
    </div>
  )
}
