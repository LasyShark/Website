"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Star, StarHalf, ShoppingBag, Truck, RotateCcw, Shield, Minus, Plus, Bolt } from "lucide-react"

import { Button } from "@/components/ui/button"
import ProductImageGallery from "@/components/product-image-gallery"
import ColorSelector from "@/components/color-selector"
import SizeSelector from "@/components/size-selector"
import ProductTabs from "@/components/product-tabs"
import RelatedProducts from "@/components/related-products"
import CustomerReviews from "@/components/customer-reviews"
import SiteHeader from "@/components/site-header"
import SiteFooter from "@/components/site-footer"

export default function ProductOverview() {
  useEffect(() => {
    // Add Google Fonts
    const link = document.createElement("link")
    link.href =
      "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap"
    link.rel = "stylesheet"
    document.head.appendChild(link)
  }, [])

  const [selectedColor, setSelectedColor] = useState("Black")
  const [selectedSize, setSelectedSize] = useState("M")
  const [quantity, setQuantity] = useState(1)
  const [showSizeGuide, setShowSizeGuide] = useState(false)

  const colors = [
    { name: "Black", hex: "#000000" },
    { name: "Brown", hex: "#8B4513" },
    { name: "Navy", hex: "#000080" },
    { name: "Burgundy", hex: "#800020" },
  ]

  const sizes = ["S", "M", "L"]

  const incrementQuantity = () => {
    setQuantity(quantity + 1)
  }

  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1)
    }
  }

  return (
    <div className="min-h-screen bg-white">
      <SiteHeader />

      {/* Main Content */}
      <main className="container mx-auto pt-24 pb-16 px-4">
        {/* Breadcrumbs */}
        <div className="py-4 text-sm text-gray-500">
          <Link href="/" className="hover:text-gray-700">
            Home
          </Link>{" "}
          /
          <Link href="/shop" className="mx-2 hover:text-gray-700">
            Shop
          </Link>{" "}
          /<span className="text-gray-700">Premium Leather Wallet</span>
        </div>

        {/* Product Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
          {/* Product Images */}
          <ProductImageGallery />

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-5xl font-bold text-gray-800 mb-2" style={{ fontFamily: "Playfair Display" }}>
                Premium Leather Wallet
              </h1>
              <div className="flex items-center mb-4">
                <div className="flex text-yellow-400 mr-2">
                  <Star className="fill-current" />
                  <Star className="fill-current" />
                  <Star className="fill-current" />
                  <Star className="fill-current" />
                  <StarHalf className="fill-current" />
                </div>
                <span className="text-gray-600">4.8 (124 reviews)</span>
              </div>
              <p className="text-2xl font-semibold text-gray-900">$89.99</p>
            </div>

            <div className="border-t border-gray-200 pt-6">
              <p className="text-gray-600 mb-6">
                Handcrafted from premium full-grain leather, this minimalist wallet combines elegance with
                functionality. Designed to age beautifully and develop a unique patina over time.
              </p>

              {/* Color Selection */}
              <ColorSelector colors={colors} selectedColor={selectedColor} setSelectedColor={setSelectedColor} />

              {/* Size Selection */}
              <SizeSelector
                sizes={sizes}
                selectedSize={selectedSize}
                setSelectedSize={setSelectedSize}
                showSizeGuide={showSizeGuide}
                setShowSizeGuide={setShowSizeGuide}
              />

              {/* Quantity Selector */}
              <div className="mb-6">
                <h3 className="font-medium text-gray-900 mb-2">Quantity</h3>
                <div className="flex items-center border border-gray-300 rounded-md w-32">
                  <button
                    className="w-10 h-10 flex items-center justify-center text-gray-600 cursor-pointer"
                    onClick={decrementQuantity}
                  >
                    <Minus className="h-4 w-4" />
                  </button>
                  <input
                    type="text"
                    className="w-12 h-10 border-none text-center bg-transparent"
                    value={quantity}
                    readOnly
                  />
                  <button
                    className="w-10 h-10 flex items-center justify-center text-gray-600 cursor-pointer"
                    onClick={incrementQuantity}
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {/* Add to Cart and Buy Now buttons */}
              <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4 mb-6">
                <Button className="flex-1 bg-amber-700 text-white hover:bg-amber-800">
                  <ShoppingBag className="mr-2 h-4 w-4" />
                  Add to Cart
                </Button>
                <Button variant="outline" className="flex-1 border-gray-900 text-gray-900">
                  <Bolt className="mr-2 h-4 w-4" />
                  Buy Now
                </Button>
              </div>

              {/* Extra Info */}
              <div className="space-y-3 text-gray-600">
                <div className="flex items-start">
                  <Truck className="mt-1 mr-3 h-4 w-4 text-gray-900" />
                  <p>Free shipping on orders over $100</p>
                </div>
                <div className="flex items-start">
                  <RotateCcw className="mt-1 mr-3 h-4 w-4 text-gray-900" />
                  <p>Free 30-day returns</p>
                </div>
                <div className="flex items-start">
                  <Shield className="mt-1 mr-3 h-4 w-4 text-gray-900" />
                  <p>2-year warranty</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details Tabs */}
        <ProductTabs />

        {/* Related Products */}
        <RelatedProducts />

        {/* Customer Reviews */}
        <CustomerReviews />
      </main>

      <SiteFooter />
    </div>
  )
}
