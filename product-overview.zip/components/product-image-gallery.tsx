"use client"

import { useState } from "react"

export default function ProductImageGallery() {
  const [mainImage, setMainImage] = useState(0)

  const productImages = [
    {
      url: "https://readdy.ai/api/search-image?query=Professional%20high%20quality%20product%20photography%20of%20a%20premium%20black%20leather%20minimalist%20wallet%20against%20a%20clean%20white%20background%2C%20studio%20lighting%2C%20detailed%20texture%20visible%2C%20commercial%20product%20shot%2C%208k%20resolution%2C%20professional%20photography&width=600&height=600&seq=1&orientation=squarish",
      alt: "Black leather wallet front view",
    },
    {
      url: "https://readdy.ai/api/search-image?query=Professional%20high%20quality%20product%20photography%20of%20a%20premium%20black%20leather%20minimalist%20wallet%20from%20side%20angle%20against%20a%20clean%20white%20background%2C%20studio%20lighting%2C%20detailed%20texture%20visible%2C%20commercial%20product%20shot%2C%208k%20resolution%2C%20professional%20photography&width=600&height=600&seq=2&orientation=squarish",
      alt: "Black leather wallet side view",
    },
    {
      url: "https://readdy.ai/api/search-image?query=Professional%20high%20quality%20product%20photography%20of%20a%20premium%20black%20leather%20minimalist%20wallet%20interior%20view%20showing%20card%20slots%20against%20a%20clean%20white%20background%2C%20studio%20lighting%2C%20detailed%20texture%20visible%2C%20commercial%20product%20shot%2C%208k%20resolution&width=600&height=600&seq=3&orientation=squarish",
      alt: "Black leather wallet interior view",
    },
    {
      url: "https://readdy.ai/api/search-image?query=Professional%20high%20quality%20product%20photography%20of%20a%20premium%20black%20leather%20minimalist%20wallet%20back%20view%20against%20a%20clean%20white%20background%2C%20studio%20lighting%2C%20detailed%20texture%20visible%2C%20commercial%20product%20shot%2C%208k%20resolution%2C%20professional%20photography&width=600&height=600&seq=4&orientation=squarish",
      alt: "Black leather wallet back view",
    },
  ]

  return (
    <div className="space-y-4">
      <div className="bg-gray-50 rounded-lg overflow-hidden h-[500px] flex items-center justify-center">
        <img
          src={productImages[mainImage].url || "/placeholder.svg"}
          alt={productImages[mainImage].alt}
          className="w-full h-full object-contain"
        />
      </div>
      <div className="grid grid-cols-4 gap-4">
        {productImages.map((image, index) => (
          <div
            key={index}
            className={`cursor-pointer bg-gray-50 rounded-md overflow-hidden h-24 ${mainImage === index ? "ring-2 ring-gray-900" : ""}`}
            onClick={() => setMainImage(index)}
          >
            <img src={image.url || "/placeholder.svg"} alt={image.alt} className="w-full h-full object-cover" />
          </div>
        ))}
      </div>
    </div>
  )
}
