"use client"

import { useState } from "react"

export default function ProductTabs() {
  const [activeTab, setActiveTab] = useState("description")

  return (
    <div className="mb-16">
      <div className="border-b border-gray-200 mb-6">
        <div className="flex space-x-8">
          {["description", "specifications", "shipping", "returns"].map((tab) => (
            <button
              key={tab}
              className={`py-4 px-1 font-medium border-b-2 ${
                activeTab === tab
                  ? "border-gray-900 text-gray-900"
                  : "border-transparent text-gray-500 hover:text-gray-700"
              }`}
              onClick={() => setActiveTab(tab)}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
      </div>
      <div className="prose max-w-none" style={{ fontFamily: "Inter" }}>
        {activeTab === "description" && (
          <div>
            <p className="mb-4">
              Our Premium Leather Wallet represents the perfect balance of form and function. Handcrafted by skilled
              artisans using traditional techniques, each wallet is made from carefully selected full-grain leather that
              will develop a beautiful patina over time, making your wallet uniquely yours.
            </p>
            <p className="mb-4">
              The minimalist design focuses on what matters most: quality materials, thoughtful organization, and a slim
              profile that fits comfortably in your pocket. With precision stitching and burnished edges, this wallet is
              built to last for years to come.
            </p>
            <h3 className="text-lg font-medium mb-2 mt-6">Features:</h3>
            <ul className="list-disc pl-6 space-y-2">
              <li>Full-grain vegetable-tanned leather</li>
              <li>6 card slots with easy-access design</li>
              <li>2 hidden pockets for additional storage</li>
              <li>Dedicated cash compartment</li>
              <li>RFID blocking technology</li>
              <li>Hand-stitched with waxed thread</li>
              <li>Personalization available</li>
            </ul>
          </div>
        )}
        {activeTab === "specifications" && (
          <div>
            <h3 className="text-lg font-medium mb-4">Product Specifications</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium mb-2">Materials</h4>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Full-grain vegetable-tanned leather</li>
                  <li>Waxed polyester thread</li>
                  <li>RFID blocking material</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Dimensions</h4>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Small: 3.4" x 4.3" x 0.4" (8.6 x 10.9 x 1.0 cm)</li>
                  <li>Medium: 3.7" x 4.5" x 0.4" (9.4 x 11.4 x 1.0 cm)</li>
                  <li>Large: 4.0" x 4.7" x 0.4" (10.2 x 11.9 x 1.0 cm)</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Capacity</h4>
                <ul className="list-disc pl-6 space-y-1">
                  <li>6 card slots</li>
                  <li>2 hidden pockets</li>
                  <li>1 cash compartment</li>
                  <li>Recommended capacity: 12 cards maximum</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Care Instructions</h4>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Wipe clean with a damp cloth</li>
                  <li>Apply leather conditioner every 3-6 months</li>
                  <li>Keep away from direct sunlight when not in use</li>
                  <li>Allow to air dry if wet</li>
                </ul>
              </div>
            </div>
          </div>
        )}
        {activeTab === "shipping" && (
          <div>
            <h3 className="text-lg font-medium mb-4">Shipping Information</h3>
            <p className="mb-4">
              We ship worldwide using trusted courier services to ensure your order arrives safely and on time.
            </p>
            <h4 className="font-medium mb-2">Domestic Shipping (United States)</h4>
            <ul className="list-disc pl-6 mb-4 space-y-1">
              <li>Free standard shipping on all orders over $100</li>
              <li>Standard shipping (3-5 business days): $5.99</li>
              <li>Express shipping (1-2 business days): $12.99</li>
            </ul>
            <h4 className="font-medium mb-2">International Shipping</h4>
            <ul className="list-disc pl-6 mb-4 space-y-1">
              <li>Standard international shipping (7-14 business days): $15.99</li>
              <li>Express international shipping (3-5 business days): $29.99</li>
              <li>Free standard international shipping on orders over $200</li>
            </ul>
            <p className="text-sm text-gray-600">
              Please note that international orders may be subject to import duties and taxes, which are the
              responsibility of the customer.
            </p>
          </div>
        )}
        {activeTab === "returns" && (
          <div>
            <h3 className="text-lg font-medium mb-4">Return Policy</h3>
            <p className="mb-4">
              We want you to be completely satisfied with your purchase. If for any reason you're not happy with your
              order, we offer a simple return process.
            </p>
            <h4 className="font-medium mb-2">Return Eligibility</h4>
            <ul className="list-disc pl-6 mb-4 space-y-1">
              <li>Items must be returned within 30 days of delivery</li>
              <li>Products must be unused, unworn, and in original condition</li>
              <li>Original packaging must be intact</li>
              <li>Proof of purchase is required</li>
            </ul>
            <h4 className="font-medium mb-2">How to Return</h4>
            <ol className="list-decimal pl-6 mb-4 space-y-1">
              <li>Contact our customer service team to initiate a return</li>
              <li>Fill out the return form included with your order</li>
              <li>Pack the item securely in its original packaging</li>
              <li>Ship the item using the provided return label</li>
            </ol>
            <p className="mb-4">
              Once we receive and inspect your return, a refund will be processed to your original payment method within
              5-7 business days.
            </p>
            <p className="text-sm text-gray-600">
              Note: Personalized items cannot be returned unless there is a manufacturing defect.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
