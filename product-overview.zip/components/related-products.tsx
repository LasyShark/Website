export default function RelatedProducts() {
  const relatedProducts = [
    {
      id: 1,
      name: "Leather Card Holder",
      price: 49.99,
      image:
        "https://readdy.ai/api/search-image?query=Professional%20high%20quality%20product%20photography%20of%20a%20slim%20leather%20card%20holder%20against%20a%20clean%20white%20background%2C%20studio%20lighting%2C%20detailed%20texture%20visible%2C%20commercial%20product%20shot%2C%208k%20resolution%2C%20professional%20photography&width=300&height=300&seq=5&orientation=squarish",
    },
    {
      id: 2,
      name: "Premium Belt",
      price: 79.99,
      image:
        "https://readdy.ai/api/search-image?query=Professional%20high%20quality%20product%20photography%20of%20a%20premium%20leather%20belt%20against%20a%20clean%20white%20background%2C%20studio%20lighting%2C%20detailed%20texture%20visible%2C%20commercial%20product%20shot%2C%208k%20resolution%2C%20professional%20photography&width=300&height=300&seq=6&orientation=squarish",
    },
    {
      id: 3,
      name: "Leather Keychain",
      price: 29.99,
      image:
        "https://readdy.ai/api/search-image?query=Professional%20high%20quality%20product%20photography%20of%20a%20leather%20keychain%20against%20a%20clean%20white%20background%2C%20studio%20lighting%2C%20detailed%20texture%20visible%2C%20commercial%20product%20shot%2C%208k%20resolution%2C%20professional%20photography&width=300&height=300&seq=7&orientation=squarish",
    },
    {
      id: 4,
      name: "Travel Wallet",
      price: 89.99,
      image:
        "https://readdy.ai/api/search-image?query=Professional%20high%20quality%20product%20photography%20of%20a%20leather%20travel%20wallet%20passport%20holder%20against%20a%20clean%20white%20background%2C%20studio%20lighting%2C%20detailed%20texture%20visible%2C%20commercial%20product%20shot%2C%208k%20resolution%2C%20professional%20photography&width=300&height=300&seq=8&orientation=squarish",
    },
    {
      id: 5,
      name: "Leather Bracelet",
      price: 39.99,
      image:
        "https://readdy.ai/api/search-image?query=Professional%20high%20quality%20product%20photography%20of%20a%20leather%20bracelet%20against%20a%20clean%20white%20background%2C%20studio%20lighting%2C%20detailed%20texture%20visible%2C%20commercial%20product%20shot%2C%208k%20resolution%2C%20professional%20photography&width=300&height=300&seq=9&orientation=squarish",
    },
  ]

  return (
    <div className="mb-16">
      <h2 className="text-3xl font-bold text-gray-800 mb-6" style={{ fontFamily: "Playfair Display" }}>
        You May Also Like
      </h2>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
        {relatedProducts.map((product) => (
          <div key={product.id} className="group">
            <div className="bg-gray-50 rounded-lg overflow-hidden mb-3 aspect-square">
              <img
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
            </div>
            <h3 className="text-xl font-medium text-gray-800" style={{ fontFamily: "Inter" }}>
              {product.name}
            </h3>
            <p className="text-gray-600 text-base">${product.price.toFixed(2)}</p>
            <button className="mt-2 text-sm font-medium text-gray-900 hover:text-gray-700">Quick view</button>
          </div>
        ))}
      </div>
    </div>
  )
}
