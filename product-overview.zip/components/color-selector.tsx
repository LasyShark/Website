"use client"

interface ColorSelectorProps {
  colors: { name: string; hex: string }[]
  selectedColor: string
  setSelectedColor: (color: string) => void
}

export default function ColorSelector({ colors, selectedColor, setSelectedColor }: ColorSelectorProps) {
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-2">
        <h3 className="font-medium text-gray-900">Color: {selectedColor}</h3>
      </div>
      <div className="flex space-x-3">
        {colors.map((color) => (
          <button
            key={color.name}
            className={`w-10 h-10 rounded-full cursor-pointer ${selectedColor === color.name ? "ring-2 ring-offset-2 ring-gray-900" : ""}`}
            style={{ backgroundColor: color.hex }}
            onClick={() => setSelectedColor(color.name)}
            aria-label={`Select ${color.name} color`}
          ></button>
        ))}
      </div>
    </div>
  )
}
