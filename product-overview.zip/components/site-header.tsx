"use client"

import Link from "next/link"
import { ShoppingBag, User, Search } from "lucide-react"

export default function SiteHeader() {
  return (
    <header className="fixed top-0 left-0 right-0 bg-white shadow-sm z-50">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex-1 flex items-center justify-center">
          <Link href="/" className="flex items-center">
            <img
              src="https://static.readdy.ai/image/78528fc9b9d09b4177519be0ab8007c6/7d65ab9ce55ac25c5de55d3ff06a128b.png"
              alt="The Cellar Guild Logo"
              className="w-8 h-8 mr-2"
            />
            <span
              className="text-3xl font-bold text-gray-800"
              style={{ fontFamily: "Playfair Display", letterSpacing: "0.15em" }}
            >
              THE CELLAR GUILD
            </span>
          </Link>
        </div>
        <nav className="hidden md:flex items-center space-x-8" style={{ fontFamily: "Inter" }}>
          <Link href="/" className="text-gray-600 hover:text-amber-700 font-medium tracking-wide text-base">
            Home
          </Link>
          <Link href="/shop" className="text-gray-800 font-medium border-b-2 border-gray-800 tracking-wide text-base">
            Shop
          </Link>
          <Link href="/collections" className="text-gray-600 hover:text-amber-700 font-medium tracking-wide text-base">
            Collections
          </Link>
          <Link href="/about" className="text-gray-600 hover:text-amber-700 font-medium tracking-wide text-base">
            About
          </Link>
          <Link href="/contact" className="text-gray-600 hover:text-amber-700 font-medium tracking-wide text-base">
            Contact
          </Link>
        </nav>
        <div className="flex items-center space-x-6">
          <button className="text-gray-600 hover:text-gray-900">
            <Search className="h-5 w-5" />
          </button>
          <button className="text-gray-600 hover:text-gray-900">
            <User className="h-5 w-5" />
          </button>
          <button className="text-gray-600 hover:text-gray-900 relative">
            <ShoppingBag className="h-5 w-5" />
            <span className="absolute -top-2 -right-2 bg-gray-900 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
              2
            </span>
          </button>
        </div>
      </div>
    </header>
  )
}
