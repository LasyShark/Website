"use client"

import { Button } from "@/components/ui/button"
import { Star } from "lucide-react"

export default function CustomerReviews() {
  const reviews = [
    {
      id: 1,
      name: "John D.",
      rating: 5,
      date: "March 15, 2025",
      title: "Excellent quality and craftsmanship",
      content:
        "I've been using this wallet for a month now and I'm extremely impressed with the quality. The leather is soft yet durable, and the stitching is perfect. Highly recommended!",
      verified: true,
    },
    {
      id: 2,
      name: "Sarah M.",
      rating: 4,
      date: "February 28, 2025",
      title: "Great wallet, slightly bigger than expected",
      content:
        "The quality is excellent and I love the design. It's slightly bigger than I expected but still fits in my pocket. The leather smells amazing and feels premium.",
      verified: true,
    },
    {
      id: 3,
      name: "Michael T.",
      rating: 5,
      date: "April 2, 2025",
      title: "Perfect minimalist wallet",
      content:
        "This is exactly what I was looking for - slim, well-made, and functional. Holds all my essential cards and some cash without bulking up my pocket. The leather is already developing a nice patina.",
      verified: true,
    },
  ]

  return (
    <div className="mb-16">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-3xl font-bold text-gray-900" style={{ fontFamily: "Playfair Display" }}>
          Customer Reviews
        </h2>
        <Button className="bg-amber-700 hover:bg-amber-800">Write a Review</Button>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        <div className="lg:col-span-1 bg-gray-50 p-6 rounded-lg">
          <div className="text-center mb-4">
            <div className="text-5xl font-bold text-gray-900 mb-2">4.8</div>
            <div className="flex justify-center text-yellow-400 mb-2">
              <Star className="fill-current" />
              <Star className="fill-current" />
              <Star className="fill-current" />
              <Star className="fill-current" />
              <Star className="fill-current text-yellow-200" />
            </div>
            <p className="text-gray-600">Based on 124 reviews</p>
          </div>
          <div className="space-y-2">
            <div className="flex items-center">
              <span className="w-16 text-sm text-gray-600">5 stars</span>
              <div className="flex-1 h-2 bg-gray-200 rounded-full mx-2">
                <div className="h-2 bg-yellow-400 rounded-full" style={{ width: "85%" }}></div>
              </div>
              <span className="w-10 text-sm text-gray-600">85%</span>
            </div>
            <div className="flex items-center">
              <span className="w-16 text-sm text-gray-600">4 stars</span>
              <div className="flex-1 h-2 bg-gray-200 rounded-full mx-2">
                <div className="h-2 bg-yellow-400 rounded-full" style={{ width: "10%" }}></div>
              </div>
              <span className="w-10 text-sm text-gray-600">10%</span>
            </div>
            <div className="flex items-center">
              <span className="w-16 text-sm text-gray-600">3 stars</span>
              <div className="flex-1 h-2 bg-gray-200 rounded-full mx-2">
                <div className="h-2 bg-yellow-400 rounded-full" style={{ width: "3%" }}></div>
              </div>
              <span className="w-10 text-sm text-gray-600">3%</span>
            </div>
            <div className="flex items-center">
              <span className="w-16 text-sm text-gray-600">2 stars</span>
              <div className="flex-1 h-2 bg-gray-200 rounded-full mx-2">
                <div className="h-2 bg-yellow-400 rounded-full" style={{ width: "1%" }}></div>
              </div>
              <span className="w-10 text-sm text-gray-600">1%</span>
            </div>
            <div className="flex items-center">
              <span className="w-16 text-sm text-gray-600">1 star</span>
              <div className="flex-1 h-2 bg-gray-200 rounded-full mx-2">
                <div className="h-2 bg-yellow-400 rounded-full" style={{ width: "1%" }}></div>
              </div>
              <span className="w-10 text-sm text-gray-600">1%</span>
            </div>
          </div>
        </div>
        <div className="lg:col-span-2">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-medium">124 reviews</h3>
            <div className="relative">
              <button className="flex items-center space-x-1 text-gray-600 border border-gray-300 rounded-md py-2 px-4">
                <span>Sort by: Most recent</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
            </div>
          </div>
          <div className="space-y-6">
            {reviews.map((review) => (
              <div key={review.id} className="border-b border-gray-200 pb-6">
                <div className="flex justify-between mb-2">
                  <div className="flex items-center">
                    <div className="flex text-yellow-400 mr-2">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`h-4 w-4 ${i < review.rating ? "fill-current" : "text-gray-300"}`} />
                      ))}
                    </div>
                    <h4 className="font-medium">{review.title}</h4>
                  </div>
                  <span className="text-sm text-gray-500">{review.date}</span>
                </div>
                <div className="flex items-center mb-2">
                  <span className="font-medium mr-2">{review.name}</span>
                  {review.verified && (
                    <span className="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded-full">
                      Verified Purchase
                    </span>
                  )}
                </div>
                <p className="text-gray-600">{review.content}</p>
              </div>
            ))}
          </div>
          <div className="mt-6 flex justify-center">
            <Button variant="outline" className="text-gray-600 border-gray-300">
              Load more reviews
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
