import ProductOverview from "@/components/product-overview"

export default function Page() {
  return <ProductOverview />
}
