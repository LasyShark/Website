"use client"

import type React from "react"
import { useState } from "react"
import { Search, ChevronDown } from "lucide-react"

const CollectionsPage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [sortBy, setSortBy] = useState("featured")
  const [priceRange, setPriceRange] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")

  const categories = ["All", "Craft Materials", "Games", "Puzzles", "Books"]
  const sortOptions = [
    { value: "featured", label: "Featured" },
    { value: "newest", label: "Newest" },
    { value: "price-low", label: "Price: Low to High" },
    { value: "price-high", label: "Price: High to Low" },
  ]

  const collections = [
    {
      id: 1,
      title: "Nordic Crafting Essentials",
      description:
        "Traditional craft materials inspired by Nordic heritage. Perfect for creating authentic handmade items.",
      itemCount: 24,
      category: "Craft Materials",
      priceRange: "30-50",
      image: "/placeholder.svg?height=400&width=600",
    },
    {
      id: 2,
      title: "Viking Strategy Games",
      description:
        "Strategic board games based on ancient Nordic traditions. Challenge your tactical thinking with these classic games.",
      itemCount: 12,
      category: "Games",
      priceRange: "over-50",
      image: "/placeholder.svg?height=400&width=600",
    },
    {
      id: 3,
      title: "Natural Dye Collection",
      description:
        "Sustainably sourced natural dyes for textile crafts. Create beautiful colors using traditional Nordic methods.",
      itemCount: 18,
      category: "Craft Materials",
      priceRange: "30-50",
      image: "/placeholder.svg?height=400&width=600",
    },
    {
      id: 4,
      title: "Nordic Folklore Library",
      description:
        "Illustrated books featuring tales and legends from Nordic tradition. Perfect for cozy reading sessions.",
      itemCount: 15,
      category: "Books",
      priceRange: "under-30",
      image: "/placeholder.svg?height=400&width=600",
    },
    {
      id: 5,
      title: "Geometric Wooden Puzzles",
      description:
        "Intricately designed wooden puzzles based on Nordic geometric patterns. Test your spatial reasoning skills.",
      itemCount: 20,
      category: "Puzzles",
      priceRange: "30-50",
      image: "/placeholder.svg?height=400&width=600",
    },
  ]

  const filteredCollections = collections
    .filter(
      (collection) =>
        (selectedCategory === "All" || collection.category === selectedCategory) &&
        (priceRange === "all" || collection.priceRange === priceRange) &&
        collection.title.toLowerCase().includes(searchQuery.toLowerCase()),
    )
    .sort((a, b) => {
      switch (sortBy) {
        case "price-low":
          return a.priceRange === "under-30" ? -1 : a.priceRange === "over-50" ? 1 : 0
        case "price-high":
          return a.priceRange === "over-50" ? -1 : a.priceRange === "under-30" ? 1 : 0
        case "newest":
          return b.id - a.id
        default:
          return 0
      }
    })

  return (
    <div className="min-h-screen bg-white">
      {/* Header with Navigation */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-4">
            <nav className="flex items-center font-serif text-sm font-medium text-gray-800 tracking-wide">
              <a href="#" className="hover:text-amber-700 cursor-pointer">
                Home
              </a>
              <span className="mx-2 text-gray-500">/</span>
              <span className="text-gray-800">Collections</span>
            </nav>
          </div>
          <div className="flex justify-center items-center py-4 space-x-2">
            <img src="/placeholder.svg?height=32&width=32" alt="The Cellar Guild Logo" className="h-8 w-8" />
            <a href="#" className="font-serif text-3xl font-bold text-gray-800 cursor-pointer tracking-wide">
              THE CELLAR GUILD
            </a>
          </div>
        </div>
      </header>

      {/* Collections Header */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-serif text-6xl font-bold text-center mb-4 tracking-wide text-gray-800">
            THE CELLAR GUILD COLLECTIONS
          </h1>
          <p className="font-sans text-base text-gray-600 text-center max-w-2xl mx-auto">
            Explore our curated selection of Nordic-inspired craft materials, games, puzzles, and books. Each collection
            is thoughtfully designed to bring the essence of Nordic craftsmanship into your home.
          </p>
        </div>
      </div>

      {/* Collections Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-1/4">
            <div className="bg-gray-50 p-6 rounded-sm sticky top-24">
              <div className="mb-8">
                <h3 className="font-serif text-3xl font-bold mb-4 text-gray-800">Search</h3>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search collections..."
                    className="w-full px-4 py-2 border-2 border-gray-200 rounded-sm focus:border-amber-700 outline-none font-sans text-lg text-gray-800"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                </div>
              </div>
              <div className="mb-8">
                <h3 className="font-serif text-3xl font-bold mb-4 text-gray-800">Categories</h3>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <button
                      key={category}
                      onClick={() => setSelectedCategory(category)}
                      className={`block w-full text-left px-4 py-2 rounded-sm transition-colors duration-200 font-sans text-base ${
                        selectedCategory === category ? "bg-amber-700 text-white" : "text-gray-800 hover:bg-gray-100"
                      } cursor-pointer`}
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>
              <div className="mb-8">
                <h3 className="font-serif text-3xl font-bold mb-4 text-gray-800">Price Range</h3>
                <div className="space-y-2">
                  {[
                    { value: "all", label: "All Prices" },
                    { value: "under-30", label: "Under $30" },
                    { value: "30-50", label: "$30 - $50" },
                    { value: "over-50", label: "Over $50" },
                  ].map((range) => (
                    <button
                      key={range.value}
                      onClick={() => setPriceRange(range.value)}
                      className={`block w-full text-left px-4 py-2 rounded-sm transition-colors duration-200 font-sans text-base ${
                        priceRange === range.value ? "bg-amber-700 text-white" : "text-gray-800 hover:bg-gray-100"
                      } cursor-pointer`}
                    >
                      {range.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Collections Grid */}
          <div className="lg:w-3/4">
            <div className="flex justify-between items-center mb-8">
              <p className="font-sans text-base text-gray-600">Showing {filteredCollections.length} collections</p>
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="appearance-none bg-white border-2 border-gray-200 rounded-sm px-4 py-2 pr-8 focus:border-amber-700 outline-none cursor-pointer font-sans text-lg text-gray-800"
                >
                  {sortOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none h-4 w-4" />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredCollections.map((collection) => (
                <div
                  key={collection.id}
                  className="group bg-white border border-gray-100 rounded-sm overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300"
                >
                  <div className="relative overflow-hidden h-48">
                    <img
                      src={collection.image || "/placeholder.svg"}
                      alt={collection.title}
                      className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="font-sans text-xl font-medium mb-2 text-gray-800">{collection.title}</h3>
                    <p className="font-sans text-base text-gray-600 mb-4 line-clamp-2">{collection.description}</p>
                    <div className="flex justify-between items-center mb-4">
                      <span className="font-sans text-sm text-gray-500">{collection.itemCount} items</span>
                      <span className="font-sans text-sm font-medium px-3 py-1 bg-gray-100 rounded-full text-gray-600">
                        {collection.category}
                      </span>
                    </div>
                    <a
                      href="#"
                      className="block w-full text-center bg-amber-700 text-white px-6 py-2 rounded-sm hover:bg-amber-800 transition-colors duration-300 cursor-pointer font-sans text-base"
                    >
                      Shop Now
                    </a>
                  </div>
                </div>
              ))}
            </div>
            {filteredCollections.length === 0 && (
              <div className="text-center py-16">
                <Search className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                <h3 className="font-serif text-xl font-medium text-gray-800 mb-2">No collections found</h3>
                <p className="font-sans text-base text-gray-600">Try adjusting your search or filter criteria</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-50 py-12 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between">
            <div className="mb-8 md:mb-0">
              <h3 className="font-serif text-3xl font-bold text-gray-800 mb-4 tracking-wide">THE CELLAR GUILD</h3>
              <p className="font-sans text-base text-gray-600 max-w-xs">
                Curating Nordic-inspired craft materials, games, puzzles, and books for your creative journey.
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
              <div>
                <h4 className="font-serif text-lg text-gray-800 mb-4">Shop</h4>
                <ul className="space-y-2 font-sans text-base text-gray-600">
                  <li>
                    <a href="#" className="hover:text-amber-700 cursor-pointer">
                      All Collections
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-amber-700 cursor-pointer">
                      Craft Materials
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-amber-700 cursor-pointer">
                      Games
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-amber-700 cursor-pointer">
                      Puzzles
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-amber-700 cursor-pointer">
                      Books
                    </a>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-serif text-lg text-gray-800 mb-4">About</h4>
                <ul className="space-y-2 font-sans text-base text-gray-600">
                  <li>
                    <a href="#" className="hover:text-amber-700 cursor-pointer">
                      Our Story
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-amber-700 cursor-pointer">
                      Sustainability
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-amber-700 cursor-pointer">
                      Craftsmanship
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-amber-700 cursor-pointer">
                      Blog
                    </a>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-serif text-lg text-gray-800 mb-4">Customer Service</h4>
                <ul className="space-y-2 font-sans text-base text-gray-600">
                  <li>
                    <a href="#" className="hover:text-amber-700 cursor-pointer">
                      Contact Us
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-amber-700 cursor-pointer">
                      Shipping & Returns
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:text-amber-700 cursor-pointer">
                      FAQ
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-200 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="font-sans text-sm text-gray-500 mb-4 md:mb-0">
              © {new Date().getFullYear()} The Cellar Guild. All rights reserved.
            </p>
            <div className="flex space-x-6">
              <a href="#" className="text-gray-400 hover:text-amber-700 cursor-pointer">
                <span className="sr-only">Facebook</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                </svg>
              </a>
              <a href="#" className="text-gray-400 hover:text-amber-700 cursor-pointer">
                <span className="sr-only">Instagram</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                  <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
                </svg>
              </a>
              <a href="#" className="text-gray-400 hover:text-amber-700 cursor-pointer">
                <span className="sr-only">Pinterest</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <line x1="12" x2="12" y1="8" y2="16" />
                  <line x1="8" x2="16" y1="12" y2="12" />
                </svg>
              </a>
              <a href="#" className="text-gray-400 hover:text-amber-700 cursor-pointer">
                <span className="sr-only">Twitter</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default CollectionsPage
