"use client"

import type React from "react"
import { useState } from "react"

const CollectionsPage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [sortBy, setSortBy] = useState("featured")
  const [priceRange, setPriceRange] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")

  const categories = ["All", "Craft Materials", "Games", "Puzzles", "Books"]
  const sortOptions = [
    { value: "featured", label: "Featured" },
    { value: "newest", label: "Newest" },
    { value: "price-low", label: "Price: Low to High" },
    { value: "price-high", label: "Price: High to Low" },
  ]

  const collections = [
    {
      id: 1,
      title: "Nordic Crafting Essentials",
      description:
        "Traditional craft materials inspired by Nordic heritage. Perfect for creating authentic handmade items.",
      itemCount: 24,
      category: "Craft Materials",
      priceRange: "30-50",
      image:
        "https://readdy.ai/api/search-image?query=Collection%20of%20Nordic%20craft%20materials%20including%20wooden%20tools%2C%20natural%20yarns%2C%20and%20fabric%20swatches%20arranged%20aesthetically%20on%20a%20light%20wooden%20surface%20with%20soft%20natural%20lighting%20and%20minimal%20styling%2C%20showcasing%20traditional%20crafting%20elements%20with%20neutral%20color%20palette&width=600&height=400&seq=col1&orientation=landscape",
    },
    // Other collection items...
  ]

  const filteredCollections = collections
    .filter(
      (collection) =>
        (selectedCategory === "All" || collection.category === selectedCategory) &&
        (priceRange === "all" || collection.priceRange === priceRange) &&
        collection.title.toLowerCase().includes(searchQuery.toLowerCase()),
    )
    .sort((a, b) => {
      switch (sortBy) {
        case "price-low":
          return a.priceRange === "under-30" ? -1 : a.priceRange === "over-50" ? 1 : 0
        case "price-high":
          return a.priceRange === "over-50" ? -1 : a.priceRange === "under-30" ? 1 : 0
        case "newest":
          return b.id - a.id
        default:
          return 0
      }
    })

  return (
    <div className="min-h-screen bg-white">
      {/* Header with Navigation */}
      <header className="bg-white shadow-sm">{/* Header content */}</header>

      {/* Collections Header */}
      <div className="bg-gray-50 py-16">
        <h1 className="font-serif text-6xl font-bold tracking-wide text-gray-800">Collections</h1>
      </div>

      {/* Collections Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-1/4">
            <h2 className="font-serif text-3xl font-bold tracking-wide text-gray-800">Filters</h2>
            {/* Filters content */}
          </div>

          {/* Collections Grid */}
          <div className="lg:w-3/4">
            <h2 className="font-serif text-3xl font-bold tracking-wide text-gray-800">Items</h2>
            {/* Collections grid content */}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-50 py-12 mt-16">{/* Footer content */}</footer>
    </div>
  )
}

export default CollectionsPage
