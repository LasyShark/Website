import CollectionsPage from "../collections-page-styled"

export default function Page() {
  return <CollectionsPage />
}
