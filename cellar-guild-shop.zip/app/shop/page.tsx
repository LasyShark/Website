"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Search, ShoppingCart, Filter, Check, ChevronDown, ChevronLeft, ChevronRight, X } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface Product {
  id: number
  name: string
  price: number
  category: string
  rating: number
  image: string
}

interface Category {
  id: string
  name: string
  icon: string
}

export default function ShopPage() {
  const [products, setProducts] = useState<Product[]>([
    {
      id: 1,
      name: "Handcrafted Wooden Rune Set",
      price: 39.99,
      category: "divination",
      rating: 4.8,
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      id: 2,
      name: "Mystic Puzzle Box",
      price: 54.99,
      category: "games",
      rating: 4.5,
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      id: 3,
      name: "Arcane Candle Set",
      price: 28.5,
      category: "home",
      rating: 4.7,
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      id: 4,
      name: "Elder Futhark Guide Book",
      price: 24.99,
      category: "books",
      rating: 4.9,
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      id: 5,
      name: "Handwoven Altar Cloth",
      price: 32.5,
      category: "ritual",
      rating: 4.6,
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      id: 6,
      name: "Crystal Divination Set",
      price: 48.75,
      category: "divination",
      rating: 4.8,
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      id: 7,
      name: "Handcrafted Wooden Wand",
      price: 36.99,
      category: "ritual",
      rating: 4.7,
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      id: 8,
      name: "Leather-bound Journal",
      price: 29.95,
      category: "stationery",
      rating: 4.6,
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      id: 9,
      name: "Nordic Tarot Deck",
      price: 42.99,
      category: "divination",
      rating: 4.9,
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      id: 10,
      name: "Handmade Ceramic Incense Holder",
      price: 19.95,
      category: "home",
      rating: 4.5,
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      id: 11,
      name: "Viking Strategy Board Game",
      price: 59.99,
      category: "games",
      rating: 4.8,
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      id: 12,
      name: "Handcrafted Mead Making Kit",
      price: 68.5,
      category: "craft",
      rating: 4.7,
      image: "/placeholder.svg?height=400&width=400",
    },
  ])

  const [filteredProducts, setFilteredProducts] = useState<Product[]>(products)
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [sortOption, setSortOption] = useState<string>("featured")
  const [showSortDropdown, setShowSortDropdown] = useState<boolean>(false)
  const [currentPage, setCurrentPage] = useState<number>(1)
  const [searchQuery, setSearchQuery] = useState<string>("")
  const [cartCount, setCartCount] = useState<number>(0)
  const [showFilters, setShowFilters] = useState<boolean>(false)
  const [showToast, setShowToast] = useState<boolean>(false)
  const [toastProduct, setToastProduct] = useState<Product | null>(null)

  const productsPerPage = 8

  const categories: Category[] = [
    { id: "divination", name: "Divination Tools", icon: "moon" },
    { id: "ritual", name: "Ritual Supplies", icon: "flame" },
    { id: "books", name: "Books & Guides", icon: "book" },
    { id: "games", name: "Games & Puzzles", icon: "puzzle" },
    { id: "home", name: "Home & Decor", icon: "home" },
    { id: "stationery", name: "Stationery", icon: "pen" },
    { id: "craft", name: "Craft Supplies", icon: "paintbrush" },
  ]

  useEffect(() => {
    let result = [...products]

    // Filter by search query
    if (searchQuery) {
      result = result.filter((product) => product.name.toLowerCase().includes(searchQuery.toLowerCase()))
    }

    // Filter by categories
    if (selectedCategories.length > 0) {
      result = result.filter((product) => selectedCategories.includes(product.category))
    }

    // Filter by price range
    result = result.filter((product) => product.price >= priceRange[0] && product.price <= priceRange[1])

    // Sort products
    switch (sortOption) {
      case "price-low-high":
        result.sort((a, b) => a.price - b.price)
        break
      case "price-high-low":
        result.sort((a, b) => b.price - a.price)
        break
      case "rating":
        result.sort((a, b) => b.rating - a.rating)
        break
      case "name-a-z":
        result.sort((a, b) => a.name.localeCompare(b.name))
        break
      case "name-z-a":
        result.sort((a, b) => b.name.localeCompare(a.name))
        break
      default: // featured or any other option
        // Keep original order
        break
    }

    setFilteredProducts(result)
    setCurrentPage(1) // Reset to first page when filters change
  }, [products, selectedCategories, priceRange, sortOption, searchQuery])

  // Get current products for pagination
  const indexOfLastProduct = currentPage * productsPerPage
  const indexOfFirstProduct = indexOfLastProduct - productsPerPage
  const currentProducts = filteredProducts.slice(indexOfFirstProduct, indexOfLastProduct)
  const totalPages = Math.ceil(filteredProducts.length / productsPerPage)

  const handleCategoryChange = (categoryId: string) => {
    if (selectedCategories.includes(categoryId)) {
      setSelectedCategories(selectedCategories.filter((id) => id !== categoryId))
    } else {
      setSelectedCategories([...selectedCategories, categoryId])
    }
  }

  const handlePriceChange = (event: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const newRange = [...priceRange] as [number, number]
    newRange[index] = Number(event.target.value)
    setPriceRange(newRange)
  }

  const handleAddToCart = (product: Product) => {
    setCartCount(cartCount + 1)
    setToastProduct(product)
    setShowToast(true)
    // Auto-hide toast after 3 seconds
    setTimeout(() => {
      setShowToast(false)
    }, 3000)
  }

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const clearFilters = () => {
    setSelectedCategories([])
    setPriceRange([0, 100])
    setSortOption("featured")
    setSearchQuery("")
  }

  // Helper function to render star ratings
  const renderStars = (rating: number) => {
    return (
      <div className="flex">
        {[1, 2, 3, 4, 5].map((star) => (
          <span key={star}>
            {star <= Math.floor(rating) ? (
              <span className="text-amber-500">★</span>
            ) : star <= rating ? (
              <span className="text-amber-500">⯨</span>
            ) : (
              <span className="text-amber-500">☆</span>
            )}
          </span>
        ))}
      </div>
    )
  }

  // Helper function to get icon for category
  const getCategoryIcon = (categoryId: string) => {
    switch (categoryId) {
      case "divination":
        return <span className="text-gray-500">🌙</span>
      case "ritual":
        return <span className="text-gray-500">🔥</span>
      case "books":
        return <span className="text-gray-500">📚</span>
      case "games":
        return <span className="text-gray-500">🎮</span>
      case "home":
        return <span className="text-gray-500">🏠</span>
      case "stationery":
        return <span className="text-gray-500">✒️</span>
      case "craft":
        return <span className="text-gray-500">🖌️</span>
      default:
        return <span className="text-gray-500">📦</span>
    }
  }

  return (
    <div className="min-h-screen bg-white font-sans">
      {/* Toast Notification */}
      {showToast && toastProduct && (
        <div
          className="fixed top-4 right-4 bg-white rounded-lg shadow-xl z-50 w-80 transform transition-all duration-300 ease-in-out"
          style={{
            animation: "slideIn 0.3s ease-out",
          }}
        >
          <style jsx>{`
            @keyframes slideIn {
              from {
                transform: translateX(100%);
                opacity: 0;
              }
              to {
                transform: translateX(0);
                opacity: 1;
              }
            }
          `}</style>
          <div className="p-4">
            <div className="flex items-start">
              <div className="w-16 h-16 relative rounded-md overflow-hidden">
                <Image
                  src={toastProduct.image || "/placeholder.svg"}
                  alt={toastProduct.name}
                  fill
                  className="object-cover"
                />
              </div>
              <div className="ml-3 flex-1">
                <p className="text-sm font-medium text-gray-900">Added to Cart!</p>
                <p className="mt-1 text-sm text-gray-500 truncate">{toastProduct.name}</p>
                <p className="mt-1 text-sm font-medium text-gray-900">${toastProduct.price.toFixed(2)}</p>
              </div>
              <button onClick={() => setShowToast(false)} className="ml-4 text-gray-400 hover:text-gray-500">
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-4">
              <Button
                onClick={() => {
                  // Handle view cart action
                  setShowToast(false)
                }}
                className="w-full bg-amber-800 text-white hover:bg-amber-900"
              >
                View Cart
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="bg-white text-gray-800 py-4 px-6 shadow-md border-b border-gray-300">
        <div className="container mx-auto flex items-center justify-between">
          <nav className="flex items-center space-x-6">
            <Link href="#" className="text-sm font-medium tracking-wide hover:text-gray-600">
              Shop
            </Link>
            <Link href="#" className="text-sm font-medium tracking-wide hover:text-gray-600">
              About
            </Link>
          </nav>
          <div className="text-center flex items-center justify-center">
            <div className="h-8 w-8 mr-2 relative">
              <Image
                src="/placeholder.svg?height=32&width=32"
                alt="The Cellar Guild Logo"
                fill
                className="object-contain"
              />
            </div>
            <h1 className="text-3xl font-serif font-bold tracking-[0.2em] text-gray-800">THE CELLAR GUILD</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="#" className="text-sm font-medium hover:text-gray-600">
              Contact
            </Link>
            <div className="relative cursor-pointer">
              <ShoppingCart className="h-5 w-5 text-gray-700" />
              <span className="absolute -top-2 -right-2 bg-gray-700 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {cartCount}
              </span>
            </div>
          </div>
        </div>
        <div className="container mx-auto mt-2">
          <div className="border-t border-gray-300"></div>
        </div>
      </header>

      {/* Breadcrumbs */}
      <div className="bg-white py-3">
        <div className="container mx-auto px-4">
          <div className="flex items-center text-sm text-gray-600">
            <Link href="#" className="hover:text-amber-700">
              Home
            </Link>
            <span className="mx-2">/</span>
            <span className="text-gray-800 font-medium">Shop All</span>
          </div>
        </div>
      </div>

      <main className="container mx-auto py-8 px-4">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-serif font-bold text-gray-800 tracking-wide">Shop All Products</h1>
          {/* Mobile filter toggle */}
          <Button onClick={() => setShowFilters(!showFilters)} variant="outline" className="md:hidden">
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </Button>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar Filters - Desktop */}
          <div
            className={`md:w-1/4 lg:w-1/5 bg-white rounded-lg shadow-md p-6 h-fit sticky top-4 ${showFilters ? "block" : "hidden md:block"}`}
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-medium text-gray-800">Filters</h2>
              <button onClick={clearFilters} className="text-amber-700 hover:text-amber-800 text-sm font-medium">
                Clear All
              </button>
            </div>

            {/* Categories */}
            <div className="mb-6">
              <h3 className="text-xl font-sans font-medium text-gray-800 mb-3">Categories</h3>
              <div className="space-y-2">
                {categories.map((category) => (
                  <div
                    key={category.id}
                    onClick={() => handleCategoryChange(category.id)}
                    className={`flex items-center p-2 rounded-md cursor-pointer transition-colors ${
                      selectedCategories.includes(category.id)
                        ? "bg-amber-50 text-amber-700"
                        : "hover:bg-gray-50 text-gray-700"
                    }`}
                  >
                    {getCategoryIcon(category.id)}
                    <span className="text-sm ml-3">{category.name}</span>
                    {selectedCategories.includes(category.id) && <Check className="ml-auto h-4 w-4 text-amber-800" />}
                  </div>
                ))}
              </div>
            </div>

            {/* Price Range */}
            <div className="mb-6">
              <h3 className="text-gray-800 font-medium mb-3">Price Range</h3>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">${priceRange[0]}</span>
                  <span className="text-gray-600">${priceRange[1]}</span>
                </div>
                <div className="relative pt-1">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={priceRange[0]}
                    onChange={(e) => handlePriceChange(e, 0)}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                  />
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={priceRange[1]}
                    onChange={(e) => handlePriceChange(e, 1)}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer mt-2"
                  />
                </div>
                <div className="flex space-x-2">
                  <div className="flex-1">
                    <label htmlFor="min-price" className="sr-only">
                      Minimum Price
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <span className="text-gray-500 sm:text-sm">$</span>
                      </div>
                      <Input
                        type="number"
                        id="min-price"
                        value={priceRange[0]}
                        onChange={(e) => handlePriceChange(e, 0)}
                        className="pl-7"
                      />
                    </div>
                  </div>
                  <div className="flex-1">
                    <label htmlFor="max-price" className="sr-only">
                      Maximum Price
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <span className="text-gray-500 sm:text-sm">$</span>
                      </div>
                      <Input
                        type="number"
                        id="max-price"
                        value={priceRange[1]}
                        onChange={(e) => handlePriceChange(e, 1)}
                        className="pl-7"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Ratings */}
            <div className="mb-6">
              <h3 className="text-gray-800 font-medium mb-3">Ratings</h3>
              <div className="space-y-2">
                {[5, 4, 3, 2, 1].map((rating) => (
                  <div key={rating} className="flex items-center">
                    <input
                      type="checkbox"
                      id={`rating-${rating}`}
                      className="h-4 w-4 text-amber-600 focus:ring-amber-500 border-gray-300 rounded"
                    />
                    <label htmlFor={`rating-${rating}`} className="ml-2 text-gray-700 cursor-pointer flex items-center">
                      {Array(rating)
                        .fill(0)
                        .map((_, i) => (
                          <span key={i} className="text-amber-500 text-sm">
                            ★
                          </span>
                        ))}
                      {Array(5 - rating)
                        .fill(0)
                        .map((_, i) => (
                          <span key={i} className="text-amber-500 text-sm">
                            ☆
                          </span>
                        ))}
                      <span className="ml-1 text-gray-600">& Up</span>
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* Mobile close button */}
            <Button
              onClick={() => setShowFilters(false)}
              className="md:hidden w-full mt-4 bg-amber-700 hover:bg-amber-800 text-white"
            >
              Apply Filters
            </Button>
          </div>

          {/* Product Grid */}
          <div className="md:w-3/4 lg:w-4/5">
            {/* Search and Sort */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
              <div className="relative w-full sm:w-64">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-gray-400" />
                </div>
                <Input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="relative w-full sm:w-auto">
                <div
                  onClick={() => setShowSortDropdown(!showSortDropdown)}
                  className="flex items-center justify-between w-full sm:w-48 px-4 py-2 bg-white border border-gray-300 rounded-md shadow-sm text-sm text-gray-700 hover:bg-gray-50 cursor-pointer"
                >
                  <span>
                    {sortOption === "featured" && "Featured"}
                    {sortOption === "price-low-high" && "Price: Low to High"}
                    {sortOption === "price-high-low" && "Price: High to Low"}
                    {sortOption === "rating" && "Highest Rated"}
                    {sortOption === "name-a-z" && "Name: A to Z"}
                    {sortOption === "name-z-a" && "Name: Z to A"}
                  </span>
                  <ChevronDown className={`h-4 w-4 transition-transform ${showSortDropdown ? "rotate-180" : ""}`} />
                </div>
                {showSortDropdown && (
                  <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-10">
                    <div className="py-1">
                      {[
                        { id: "featured", name: "Featured" },
                        { id: "price-low-high", name: "Price: Low to High" },
                        { id: "price-high-low", name: "Price: High to Low" },
                        { id: "rating", name: "Highest Rated" },
                        { id: "name-a-z", name: "Name: A to Z" },
                        { id: "name-z-a", name: "Name: Z to A" },
                      ].map((option) => (
                        <div
                          key={option.id}
                          onClick={() => {
                            setSortOption(option.id)
                            setShowSortDropdown(false)
                          }}
                          className={`px-4 py-2 text-sm cursor-pointer hover:bg-gray-100 ${sortOption === option.id ? "text-amber-700 font-medium" : "text-gray-700"}`}
                        >
                          {option.name}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Results Count */}
            <div className="mb-6 text-gray-600">
              Showing {Math.min(filteredProducts.length, (currentPage - 1) * productsPerPage + 1)}-
              {Math.min(filteredProducts.length, currentPage * productsPerPage)} of {filteredProducts.length} products
            </div>

            {/* Products Grid */}
            {currentProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {currentProducts.map((product) => (
                  <div
                    key={product.id}
                    className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:scale-[1.02]"
                  >
                    <div className="relative group">
                      <div className="w-full h-64 relative">
                        <Image
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          fill
                          className="object-cover object-top"
                        />
                      </div>
                      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-opacity duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
                        <Button variant="secondary" className="mx-2">
                          Quick View
                        </Button>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="flex items-center mb-2">
                        {renderStars(product.rating)}
                        <span className="ml-1 text-gray-600 text-sm">{product.rating}</span>
                      </div>
                      <h3 className="font-sans text-xl font-medium text-gray-800 mb-2">{product.name}</h3>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-800 font-medium">${product.price.toFixed(2)}</span>
                        <Button
                          onClick={() => handleAddToCart(product)}
                          className="bg-amber-800 hover:bg-amber-900 text-white px-3 py-1 h-auto text-sm shadow-lg hover:shadow-xl"
                        >
                          Add to Cart
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow-md p-8 text-center">
                <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-medium text-gray-800 mb-2">No products found</h3>
                <p className="text-gray-600 mb-6">Try adjusting your filters or search criteria.</p>
                <Button onClick={clearFilters} className="bg-amber-800 hover:bg-amber-900 text-white">
                  Clear Filters
                </Button>
              </div>
            )}

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-8 flex justify-center">
                <nav className="flex items-center space-x-2">
                  <Button
                    onClick={() => handlePageChange(Math.max(1, currentPage - 1))}
                    disabled={currentPage === 1}
                    variant="outline"
                    size="icon"
                    className={currentPage === 1 ? "text-gray-400 cursor-not-allowed" : "text-gray-700"}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                    <Button
                      key={page}
                      onClick={() => handlePageChange(page)}
                      variant={currentPage === page ? "default" : "outline"}
                      className={currentPage === page ? "bg-amber-800 text-white hover:bg-amber-800" : ""}
                    >
                      {page}
                    </Button>
                  ))}
                  <Button
                    onClick={() => handlePageChange(Math.min(totalPages, currentPage + 1))}
                    disabled={currentPage === totalPages}
                    variant="outline"
                    size="icon"
                    className={currentPage === totalPages ? "text-gray-400 cursor-not-allowed" : "text-gray-700"}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </nav>
              </div>
            )}
          </div>
        </div>
      </main>

      <footer className="bg-white text-gray-800 py-12 mt-16 border-t border-gray-200">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-3xl font-serif font-bold tracking-[0.15em] text-gray-800 mb-4">THE CELLAR GUILD</h3>
              <p className="text-gray-600 mb-4">
                Crafting mystical experiences since 2015. Our handcrafted items bring ancient wisdom to modern life.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-500 hover:text-amber-800">
                  <span className="sr-only">Facebook</span>
                </a>
                <a href="#" className="text-gray-500 hover:text-amber-800">
                  <span className="sr-only">Instagram</span>
                </a>
                <a href="#" className="text-gray-500 hover:text-amber-800">
                  <span className="sr-only">Twitter</span>
                </a>
                <a href="#" className="text-gray-500 hover:text-amber-800">
                  <span className="sr-only">Pinterest</span>
                </a>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-serif font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-gray-500 hover:text-amber-700">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-500 hover:text-amber-800">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-500 hover:text-amber-800">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-500 hover:text-amber-800">
                    FAQ
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-gray-500 hover:text-amber-800">
                    Shipping & Returns
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-serif font-semibold mb-4">Newsletter</h3>
              <p className="text-base font-sans text-gray-600 mb-4">
                Subscribe to receive updates, access to exclusive deals, and more.
              </p>
              <div className="flex">
                <Input type="email" placeholder="Your email address" className="rounded-r-none" />
                <Button className="bg-amber-800 hover:bg-amber-900 text-white rounded-l-none shadow-md">
                  Subscribe
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-300 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-500 text-sm">&copy; 2025 The Cellar Guild. All rights reserved.</p>
            <div className="mt-4 md:mt-0 flex space-x-4">
              <Link href="#" className="text-gray-500 hover:text-amber-700 text-sm">
                Privacy Policy
              </Link>
              <Link href="#" className="text-gray-500 hover:text-amber-700 text-sm">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
