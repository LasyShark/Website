import Image from "next/image"
import Link from "next/link"

export function Footer() {
  return (
    <footer className="bg-gray-100 text-gray-800 py-16">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-3 mb-6">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="The Cellar Guild Logo"
                width={40}
                height={40}
                className="h-10 w-10"
              />
              <h3 className="text-2xl font-bold font-serif text-gray-800">THE CELLAR GUILD</h3>
            </div>
            <p className="text-gray-600 mb-8 text-base leading-relaxed max-w-md font-sans">
              Curating extraordinary collections of games, puzzles, and literature to inspire imagination and create
              lasting memories.
            </p>
            <div className="flex space-x-6">
              <a href="#" className="text-gray-600 hover:text-amber-700 transition-colors duration-300">
                <span className="sr-only">Twitter</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path d="M22 4.01c-1 .49-1.98.689-3 .99-1.121-1.265-2.783-1.335-4.38-.737S11.977 6.323 12 8v1c-3.245.083-6.135-1.395-8-4 0 0-4.182 7.433 4 11-1.872 1.247-3.739 2.088-6 2 3.308 1.803 6.913 2.423 10.034 1.517 3.58-1.04 6.522-3.723 7.651-7.742a13.84 13.84 0 0 0 .497-3.753C20.18 7.773 21.692 5.25 22 4.009z" />
                </svg>
              </a>
              <a href="#" className="text-gray-600 hover:text-amber-700 transition-colors duration-300">
                <span className="sr-only">Facebook</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                </svg>
              </a>
              <a href="#" className="text-gray-600 hover:text-amber-700 transition-colors duration-300">
                <span className="sr-only">Instagram</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                </svg>
              </a>
              <a href="#" className="text-gray-600 hover:text-amber-700 transition-colors duration-300">
                <span className="sr-only">Pinterest</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.012 8.012 0 0 0 16 8c0-4.42-3.58-8-8-8z" />
                </svg>
              </a>
            </div>
          </div>
          <div>
            <h4 className="text-xl font-bold font-serif mb-6 text-gray-800 tracking-wide">Explore</h4>
            <ul className="space-y-4">
              <li>
                <Link
                  href="/new-arrivals"
                  className="text-gray-600 hover:text-amber-700 transition-colors duration-300 block font-sans text-base"
                >
                  New Arrivals
                </Link>
              </li>
              <li>
                <Link
                  href="/best-sellers"
                  className="text-gray-600 hover:text-amber-700 transition-colors duration-300 block font-sans text-base"
                >
                  Best Sellers
                </Link>
              </li>
              <li>
                <Link
                  href="/gift-cards"
                  className="text-gray-600 hover:text-amber-700 transition-colors duration-300 block font-sans text-base"
                >
                  Gift Cards
                </Link>
              </li>
              <li>
                <Link
                  href="/membership"
                  className="text-gray-600 hover:text-amber-700 transition-colors duration-300 block font-sans text-base"
                >
                  Membership
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-xl font-bold font-serif mb-6 text-gray-800">Support</h4>
            <ul className="space-y-4">
              <li>
                <Link
                  href="/contact"
                  className="text-gray-600 hover:text-amber-700 transition-colors duration-300 block font-sans text-base"
                >
                  Contact Us
                </Link>
              </li>
              <li>
                <Link
                  href="/shipping"
                  className="text-gray-600 hover:text-amber-700 transition-colors duration-300 block font-sans text-base"
                >
                  Shipping Info
                </Link>
              </li>
              <li>
                <Link
                  href="/returns"
                  className="text-gray-600 hover:text-amber-700 transition-colors duration-300 block font-sans text-base"
                >
                  Returns
                </Link>
              </li>
              <li>
                <Link
                  href="/faq"
                  className="text-gray-600 hover:text-amber-700 transition-colors duration-300 block font-sans text-base"
                >
                  FAQ
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-200 mt-16 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-600 text-sm font-sans">© 2025 The Cellar Guild. All rights reserved.</p>
          <div className="mt-6 md:mt-0 flex items-center space-x-6">
            <div className="flex items-center space-x-4 text-gray-600">
              <span className="text-2xl hover:text-amber-700 transition-colors duration-300">💳</span>
              <span className="text-2xl hover:text-amber-700 transition-colors duration-300">💳</span>
              <span className="text-2xl hover:text-amber-700 transition-colors duration-300">💳</span>
              <span className="text-2xl hover:text-amber-700 transition-colors duration-300">💳</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
