export function CoreValues() {
  const values = [
    {
      icon: "🏆",
      title: "Quality",
      description: "We carefully curate premium products that meet our high standards of craftsmanship and design.",
    },
    {
      icon: "💰",
      title: "Affordability",
      description: "We strive to offer fair prices while maintaining the exceptional quality of our collection.",
    },
    {
      icon: "🤝",
      title: "Ease",
      description: "We make your shopping experience simple and enjoyable from browsing to delivery.",
    },
  ]

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-12 font-serif">Our Core Values</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {values.map((value, index) => (
            <div key={index} className="text-center p-6 transition duration-300 hover:transform hover:scale-105">
              <div className="bg-amber-100 rounded-full p-4 w-20 h-20 flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl text-amber-600">{value.icon}</span>
              </div>
              <h3 className="text-2xl font-semibold text-gray-800 mb-3 font-serif">{value.title}</h3>
              <p className="text-gray-600 font-sans text-base">{value.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
