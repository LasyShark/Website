"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

export function ContactForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [id]: value,
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission logic here
    console.log("Form submitted:", formData)
    // Reset form or show success message
  }

  return (
    <div className="p-8">
      <form onSubmit={handleSubmit}>
        <div className="mb-6">
          <Label htmlFor="name" className="block text-gray-800 font-medium mb-2 font-sans text-base">
            Name
          </Label>
          <Input
            type="text"
            id="name"
            value={formData.name}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-lg font-sans text-gray-800"
            placeholder="Your name"
            required
          />
        </div>
        <div className="mb-6">
          <Label htmlFor="email" className="block text-gray-800 font-medium mb-2 font-sans text-base">
            Email
          </Label>
          <Input
            type="email"
            id="email"
            value={formData.email}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-lg font-sans text-gray-800"
            placeholder="Your email"
            required
          />
        </div>
        <div className="mb-6">
          <Label htmlFor="message" className="block text-gray-800 font-medium mb-2 font-sans text-base">
            Message
          </Label>
          <Textarea
            id="message"
            value={formData.message}
            onChange={handleChange}
            rows={4}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-lg font-sans text-gray-800"
            placeholder="Your message"
            required
          />
        </div>
        <Button
          type="submit"
          className="bg-amber-700 text-white px-6 py-3 rounded-sm hover:bg-amber-800 transition duration-300 font-sans text-base"
        >
          Send Message
        </Button>
      </form>
    </div>
  )
}
