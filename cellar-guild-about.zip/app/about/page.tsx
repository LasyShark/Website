import Image from "next/image"
import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ContactForm } from "@/components/contact-form"
import { CoreValues } from "@/components/core-values"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-stone-50 to-amber-50">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0">
              <h2 className="text-6xl font-bold font-serif text-gray-800 leading-tight mb-4">Welcome To The Guild</h2>
              <p className="text-lg text-gray-600 mb-8 font-sans">
                Discover our carefully selected collection of unique games, puzzles, and engaging literature that will
                inspire your imagination.
              </p>
              <Link
                href="/collections"
                className="bg-amber-700 text-white px-8 py-3 rounded-sm hover:bg-amber-800 transition duration-300 shadow-md inline-block font-serif text-base"
              >
                Explore Collection
              </Link>
            </div>
            <div className="md:w-1/2 relative">
              <div className="rounded-lg overflow-hidden shadow-xl">
                <Image
                  src="/placeholder.svg?height=400&width=600"
                  alt="The Cellar Guild Shop"
                  width={600}
                  height={400}
                  className="w-full h-full object-cover object-top"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Company Story */}
      <section className="py-16 bg-stone-50">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold font-serif text-center text-gray-800 mb-12">Our Story</h2>
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-semibold text-gray-800 mb-3 font-serif">How We Started</h3>
                <p className="text-base text-gray-600 leading-relaxed font-sans">
                  Founded in 2025 as a means of providing a service to people worldwide in the face of the economic
                  barriers that are being erected in free trade. This company is a means of preserving and following
                  that belief albeit challenged at every possibility.
                </p>
              </div>
              <div>
                <h3 className="text-2xl font-semibold text-gray-800 mb-3 font-serif">Our Mission</h3>
                <p className="text-base text-gray-600 leading-relaxed font-sans">
                  At The Cellar Guild, we're dedicated to bringing moments of joy and tranquility into people's lives
                  through our carefully curated collection of games, puzzles, and books. We believe that taking time to
                  engage in meaningful activities can create lasting memories and provide a peaceful escape from the
                  daily hustle. Our mission is to help people discover treasured items that bring enrichment and
                  enjoyment to their quiet moments of reflection.
                </p>
              </div>
              <div>
                <h3 className="text-2xl font-semibold text-gray-800 mb-3 font-serif">Looking Forward</h3>
                <p className="text-base text-gray-600 leading-relaxed font-sans">
                  The goal is to sell products to enhance the quality of our customers lives as they explore new hobbies
                  and enhance their existing ones. We believe in the power of leisure activities to bring joy,
                  relaxation, and personal growth to everyone's daily life. Through our carefully selected collection,
                  we aim to inspire and support our customers in their journey of discovery and enjoyment.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <CoreValues />

      {/* Contact Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-gray-800 mb-12 font-serif">Get In Touch</h2>
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="p-8 bg-amber-700 text-white">
                  <h3 className="text-2xl font-semibold mb-6 font-serif">Contact Information</h3>
                  <div className="space-y-6">
                    <div className="flex items-start space-x-4">
                      <span className="text-xl mt-1">✉️</span>
                      <div>
                        <h4 className="font-medium font-sans">Email</h4>
                        <p className="mt-1 font-sans text-base">hello@cellarguild.com</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-4">
                      <span className="text-xl mt-1">📞</span>
                      <div>
                        <h4 className="font-medium font-sans">Phone</h4>
                        <p className="mt-1 font-sans text-base">+1 (415) 555-0123</p>
                      </div>
                    </div>
                  </div>
                  <div className="mt-10">
                    <h4 className="font-medium mb-4 font-sans">Follow Us</h4>
                    <div className="flex space-x-4">
                      <a
                        href="#"
                        className="bg-amber-600 hover:bg-amber-500 h-10 w-10 rounded-full flex items-center justify-center transition duration-300"
                      >
                        <span>𝕏</span>
                      </a>
                      <a
                        href="#"
                        className="bg-amber-600 hover:bg-amber-500 h-10 w-10 rounded-full flex items-center justify-center transition duration-300"
                      >
                        <span>in</span>
                      </a>
                      <a
                        href="#"
                        className="bg-amber-600 hover:bg-amber-500 h-10 w-10 rounded-full flex items-center justify-center transition duration-300"
                      >
                        <span>📷</span>
                      </a>
                    </div>
                  </div>
                </div>
                <ContactForm />
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
