import type React from "react"
import "@fortawesome/fontawesome-svg-core/styles.css"
import { config } from "@fortawesome/fontawesome-svg-core"
import "./globals.css"

// Prevent Font Awesome from adding its CSS since we did it manually above
config.autoAddCss = false

export const metadata = {
  title: "The Cellar Guild",
  description: "Curating extraordinary collections of games, puzzles, and literature",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
