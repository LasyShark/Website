"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import {
  Bell,
  Check,
  ChevronDown,
  ChevronRight,
  Cog,
  ComputerIcon as Desktop,
  Download,
  TriangleIcon as ExclamationTriangle,
  File,
  Home,
  LinkIcon,
  LogOut,
  Moon,
  Palette,
  Search,
  Shield,
  Sun,
  Trash2,
  User,
  UserCircle,
} from "lucide-react"

export default function AccountSettings() {
  const [activeSection, setActiveSection] = useState("personal")
  const [theme, setTheme] = useState("light")
  const [formData, setFormData] = useState({
    firstName: "Alex",
    lastName: "Morgan",
    username: "alexmorgan",
    email: "alex.morgan@example.com",
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
    twoFactorEnabled: true,
    receiveEmails: true,
    publicProfile: true,
    onlineStatus: true,
  })
  const [passwordError, setPasswordError] = useState("")
  const [successMessage, setSuccessMessage] = useState("")
  const [showNotifications, setShowNotifications] = useState(false)
  const [showProfileDropdown, setShowProfileDropdown] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value,
    })

    if (name === "newPassword" || name === "confirmPassword") {
      setPasswordError("")
    }
  }

  const handleToggleChange = (field: string) => {
    setFormData({
      ...formData,
      [field as keyof typeof formData]: !formData[field as keyof typeof formData],
    })
  }

  const validatePasswords = () => {
    if (formData.newPassword && formData.newPassword.length < 8) {
      setPasswordError("Password must be at least 8 characters long")
      return false
    }

    if (formData.newPassword !== formData.confirmPassword) {
      setPasswordError("Passwords do not match")
      return false
    }

    return true
  }

  const handleSavePersonalInfo = (e: React.FormEvent) => {
    e.preventDefault()
    // Simulate API call
    setTimeout(() => {
      setSuccessMessage("Personal information updated successfully")
      setTimeout(() => setSuccessMessage(""), 3000)
    }, 500)
  }

  const handleSavePassword = (e: React.FormEvent) => {
    e.preventDefault()
    if (validatePasswords()) {
      // Simulate API call
      setTimeout(() => {
        setSuccessMessage("Password updated successfully")
        setFormData({
          ...formData,
          currentPassword: "",
          newPassword: "",
          confirmPassword: "",
        })
        setTimeout(() => setSuccessMessage(""), 3000)
      }, 500)
    }
  }

  const handleThemeChange = (selectedTheme: string) => {
    setTheme(selectedTheme)
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 bg-white/95 border-b border-gray-200 backdrop-blur-sm z-50">
        <div className="max-w-6xl mx-auto px-6">
          <nav className="flex items-center justify-between h-20">
            <div className="flex items-center">
              <Image
                src="/placeholder.svg?height=32&width=32"
                alt="The Cellar Guild Logo"
                width={32}
                height={32}
                className="mr-3"
              />
              <h1 className="text-2xl font-serif font-bold text-gray-800 tracking-wider">THE CELLAR GUILD</h1>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <Link href="#" className="text-lg text-gray-600 hover:text-gray-800 font-medium font-serif">
                Discover
              </Link>
              <Link href="#" className="text-lg text-gray-600 hover:text-gray-800 font-medium font-serif">
                Categories
              </Link>
              <Link href="#" className="text-lg text-gray-600 hover:text-gray-800 font-medium font-serif">
                Popular
              </Link>
              <Link href="#" className="text-lg text-gray-600 hover:text-gray-800 font-medium font-serif">
                New
              </Link>
              <Link href="#" className="text-lg text-gray-600 hover:text-gray-800 font-medium font-serif">
                My Communities
              </Link>
            </div>
            <div className="flex items-center space-x-6">
              <button className="hidden md:block text-gray-600 hover:text-gray-900">
                <Search className="h-5 w-5" />
              </button>
              <div className="relative">
                <button
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="text-gray-600 hover:text-gray-900 relative"
                >
                  <Bell className="h-5 w-5" />
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                    3
                  </span>
                </button>
                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
                    <div className="p-4 border-b border-gray-100">
                      <div className="flex justify-between items-center">
                        <h3 className="text-lg font-medium text-gray-800">Notifications</h3>
                        <button className="text-sm text-amber-700 hover:text-amber-800">Mark all as read</button>
                      </div>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      <div className="notification-item bg-amber-50 p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50">
                        <div className="flex items-start">
                          <User className="text-amber-700 h-4 w-4 mt-1" />
                          <div className="ml-3">
                            <p className="text-sm text-gray-800">New community invite from Developers Hub</p>
                            <p className="text-xs text-gray-500 mt-1">2 minutes ago</p>
                          </div>
                        </div>
                      </div>
                      <div className="notification-item bg-amber-50 p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50">
                        <div className="flex items-start">
                          <div className="ml-3">
                            <p className="text-sm text-gray-800">You were mentioned in Digital Artists United</p>
                            <p className="text-xs text-gray-500 mt-1">1 hour ago</p>
                          </div>
                        </div>
                      </div>
                      <div className="notification-item bg-amber-50 p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50">
                        <div className="flex items-start">
                          <Bell className="text-amber-700 h-4 w-4 mt-1" />
                          <div className="ml-3">
                            <p className="text-sm text-gray-800">New event scheduled in Game Dev League</p>
                            <p className="text-xs text-gray-500 mt-1">2 hours ago</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="p-4 text-center border-t border-gray-100">
                      <Link href="#" className="text-sm text-amber-700 hover:text-amber-800">
                        View all notifications
                      </Link>
                    </div>
                  </div>
                )}
              </div>
              <div className="relative">
                <button
                  onClick={() => setShowProfileDropdown(!showProfileDropdown)}
                  className="text-gray-600 hover:text-gray-900"
                >
                  <UserCircle className="h-5 w-5" />
                </button>
                {showProfileDropdown && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
                    <div className="py-2">
                      <Link href="#" className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                        <User className="h-4 w-4 mr-3 text-gray-400" />
                        My Profile
                      </Link>
                      <Link href="#" className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                        <Cog className="h-4 w-4 mr-3 text-gray-400" />
                        Account Settings
                      </Link>
                      <Link href="#" className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                        <LogOut className="h-4 w-4 mr-3 text-gray-400" />
                        Log Out
                      </Link>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <div className="pt-32 pb-6">
        <div className="max-w-6xl mx-auto px-6">
          {/* Breadcrumb */}
          <div className="mb-8">
            <nav className="flex" aria-label="Breadcrumb">
              <ol className="inline-flex items-center space-x-1 md:space-x-3">
                <li className="inline-flex items-center">
                  <Link
                    href="#"
                    className="inline-flex items-center text-sm font-medium text-gray-600 hover:text-amber-700"
                  >
                    <Home className="h-4 w-4 mr-2" />
                    Home
                  </Link>
                </li>
                <li>
                  <div className="flex items-center">
                    <ChevronRight className="text-gray-400 h-4 w-4 mx-1" />
                    <Link href="#" className="ml-1 text-sm font-medium text-gray-600 hover:text-amber-700">
                      Profile
                    </Link>
                  </div>
                </li>
                <li aria-current="page">
                  <div className="flex items-center">
                    <ChevronRight className="text-gray-400 h-4 w-4 mx-1" />
                    <span className="ml-1 text-sm font-medium text-gray-500">Account Settings</span>
                  </div>
                </li>
              </ol>
            </nav>
          </div>

          {/* Page Title */}
          <div className="mb-10">
            <h1 className="text-6xl font-serif font-bold text-gray-800">Account Settings</h1>
            <p className="text-gray-600 mt-4">Manage your account preferences and personal information</p>
          </div>

          {/* Settings Layout */}
          <div className="flex flex-col md:flex-row gap-8">
            {/* Sidebar */}
            <div className="md:w-1/4">
              <div className="bg-white rounded-lg shadow-sm p-6 sticky top-32">
                <h3 className="text-xl font-serif text-gray-800 mb-6">Settings</h3>
                <ul className="space-y-2">
                  <li>
                    <button
                      onClick={() => setActiveSection("personal")}
                      className={`w-full text-left px-4 py-2 rounded-md flex items-center ${activeSection === "personal" ? "bg-amber-50 text-amber-700" : "text-gray-700 hover:bg-gray-50"}`}
                    >
                      <User
                        className={`h-4 w-4 mr-3 ${activeSection === "personal" ? "text-amber-700" : "text-gray-500"}`}
                      />
                      Personal Information
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => setActiveSection("security")}
                      className={`w-full text-left px-4 py-2 rounded-md flex items-center ${activeSection === "security" ? "bg-amber-50 text-amber-700" : "text-gray-700 hover:bg-gray-50"}`}
                    >
                      <Shield
                        className={`h-4 w-4 mr-3 ${activeSection === "security" ? "text-amber-700" : "text-gray-500"}`}
                      />
                      Security
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => setActiveSection("connected")}
                      className={`w-full text-left px-4 py-2 rounded-md flex items-center ${activeSection === "connected" ? "bg-amber-50 text-amber-700" : "text-gray-700 hover:bg-gray-50"}`}
                    >
                      <LinkIcon
                        className={`h-4 w-4 mr-3 ${activeSection === "connected" ? "text-amber-700" : "text-gray-500"}`}
                      />
                      Connected Accounts
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => setActiveSection("management")}
                      className={`w-full text-left px-4 py-2 rounded-md flex items-center ${activeSection === "management" ? "bg-amber-50 text-amber-700" : "text-gray-700 hover:bg-gray-50"}`}
                    >
                      <Cog
                        className={`h-4 w-4 mr-3 ${activeSection === "management" ? "text-amber-700" : "text-gray-500"}`}
                      />
                      Account Management
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => setActiveSection("appearance")}
                      className={`w-full text-left px-4 py-2 rounded-md flex items-center ${activeSection === "appearance" ? "bg-amber-50 text-amber-700" : "text-gray-700 hover:bg-gray-50"}`}
                    >
                      <Palette
                        className={`h-4 w-4 mr-3 ${activeSection === "appearance" ? "text-amber-700" : "text-gray-500"}`}
                      />
                      Appearance
                    </button>
                  </li>
                </ul>
              </div>
            </div>

            {/* Main Content */}
            <div className="md:w-3/4">
              {/* Success Message */}
              {successMessage && (
                <div className="bg-green-100 border-l-4 border-green-600 text-green-600 p-4 mb-6 rounded-md">
                  <div className="flex items-center">
                    <Check className="h-5 w-5 mr-2" />
                    <p>{successMessage}</p>
                  </div>
                </div>
              )}

              {/* Personal Information */}
              {activeSection === "personal" && (
                <div className="bg-white rounded-lg shadow-sm p-8">
                  <h2 className="text-3xl font-serif text-gray-800 mb-6">Personal Information</h2>
                  <form onSubmit={handleSavePersonalInfo}>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      <div>
                        <label htmlFor="firstName" className="block text-base text-gray-800 mb-2">
                          First Name
                        </label>
                        <input
                          type="text"
                          id="firstName"
                          name="firstName"
                          value={formData.firstName}
                          onChange={handleInputChange}
                          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-amber-500 focus:border-transparent text-lg"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="lastName" className="block text-base text-gray-800 mb-2">
                          Last Name
                        </label>
                        <input
                          type="text"
                          id="lastName"
                          name="lastName"
                          value={formData.lastName}
                          onChange={handleInputChange}
                          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-amber-500 focus:border-transparent text-lg"
                          required
                        />
                      </div>
                    </div>
                    <div className="mb-6">
                      <label htmlFor="username" className="block text-base text-gray-800 mb-2">
                        Username
                      </label>
                      <div className="flex">
                        <span className="inline-flex items-center px-3 text-gray-500 bg-gray-100 border border-r-0 border-gray-300 rounded-l-md">
                          @
                        </span>
                        <input
                          type="text"
                          id="username"
                          name="username"
                          value={formData.username}
                          onChange={handleInputChange}
                          className="flex-1 px-4 py-2 border border-gray-300 rounded-r-md focus:ring-2 focus:ring-amber-500 focus:border-transparent text-lg"
                          required
                        />
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        This will be your public username visible to other users.
                      </p>
                    </div>
                    <div className="mb-6">
                      <label htmlFor="email" className="block text-base text-gray-800 mb-2">
                        Email Address
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-amber-500 focus:border-transparent text-lg"
                        required
                      />
                      <p className="text-xs text-gray-500 mt-1">We'll send account notifications to this email.</p>
                    </div>
                    <div className="mb-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-gray-800">Receive Email Updates</p>
                          <p className="text-sm text-gray-500">Get notifications about new features and updates</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleToggleChange("receiveEmails")}
                          className={`w-12 h-6 rounded-full ${formData.receiveEmails ? "bg-amber-700" : "bg-gray-200"} relative`}
                        >
                          <div
                            className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-all ${formData.receiveEmails ? "right-1" : "left-1"}`}
                          ></div>
                        </button>
                      </div>
                    </div>
                    <div className="flex justify-end">
                      <button
                        type="submit"
                        className="bg-amber-700 text-white px-6 py-2 rounded-md hover:bg-amber-800 transition-colors"
                      >
                        Save Changes
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Security */}
              {activeSection === "security" && (
                <div className="bg-white rounded-lg shadow-sm p-8">
                  <h2 className="text-3xl font-serif text-gray-800 mb-6">Security</h2>

                  {/* Password Change */}
                  <div className="mb-10">
                    <h3 className="text-xl font-serif text-gray-800 mb-4">Change Password</h3>
                    <form onSubmit={handleSavePassword}>
                      <div className="mb-4">
                        <label htmlFor="currentPassword" className="block text-base text-gray-800 mb-2">
                          Current Password
                        </label>
                        <input
                          type="password"
                          id="currentPassword"
                          name="currentPassword"
                          value={formData.currentPassword}
                          onChange={handleInputChange}
                          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-amber-500 focus:border-transparent text-lg"
                          required
                        />
                      </div>
                      <div className="mb-4">
                        <label htmlFor="newPassword" className="block text-base text-gray-800 mb-2">
                          New Password
                        </label>
                        <input
                          type="password"
                          id="newPassword"
                          name="newPassword"
                          value={formData.newPassword}
                          onChange={handleInputChange}
                          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-amber-500 focus:border-transparent text-lg"
                          required
                        />
                        <p className="text-xs text-gray-500 mt-1">Password must be at least 8 characters long.</p>
                      </div>
                      <div className="mb-4">
                        <label htmlFor="confirmPassword" className="block text-base text-gray-800 mb-2">
                          Confirm New Password
                        </label>
                        <input
                          type="password"
                          id="confirmPassword"
                          name="confirmPassword"
                          value={formData.confirmPassword}
                          onChange={handleInputChange}
                          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-amber-500 focus:border-transparent text-lg"
                          required
                        />
                      </div>
                      {passwordError && (
                        <div className="mb-4 text-red-600 text-sm">
                          <ExclamationTriangle className="h-4 w-4 inline mr-2" />
                          {passwordError}
                        </div>
                      )}
                      <div className="flex justify-end">
                        <button
                          type="submit"
                          className="bg-amber-700 text-white px-6 py-2 rounded-md hover:bg-amber-800 transition-colors"
                        >
                          Update Password
                        </button>
                      </div>
                    </form>
                  </div>

                  {/* Two-Factor Authentication */}
                  <div className="border-t border-gray-200 pt-8">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-serif text-gray-800">Two-Factor Authentication</h3>
                        <p className="text-sm text-gray-500 mt-1">Add an extra layer of security to your account</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleToggleChange("twoFactorEnabled")}
                        className={`w-12 h-6 rounded-full ${formData.twoFactorEnabled ? "bg-amber-700" : "bg-gray-200"} relative`}
                      >
                        <div
                          className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-all ${formData.twoFactorEnabled ? "right-1" : "left-1"}`}
                        ></div>
                      </button>
                    </div>

                    {formData.twoFactorEnabled && (
                      <div className="bg-gray-50 p-4 rounded-md">
                        <p className="text-gray-700 mb-2">Two-factor authentication is enabled for your account.</p>
                        <button className="text-amber-700 hover:text-amber-800 font-medium">Configure Settings</button>
                      </div>
                    )}
                  </div>

                  {/* Login History */}
                  <div className="border-t border-gray-200 pt-8 mt-8">
                    <h3 className="text-xl font-serif text-gray-800 mb-4">Recent Login Activity</h3>
                    <div className="bg-gray-50 rounded-md overflow-hidden">
                      <div className="p-4 border-b border-gray-200">
                        <div className="flex items-start">
                          <Desktop className="text-gray-500 h-5 w-5 mt-1 mr-3" />
                          <div>
                            <p className="text-gray-800">MacBook Pro - Chrome</p>
                            <p className="text-xs text-gray-500">New York, USA - April 18, 2025 at 9:30 AM</p>
                          </div>
                          <span className="ml-auto bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full">
                            Current
                          </span>
                        </div>
                      </div>
                      <div className="p-4 border-b border-gray-200">
                        <div className="flex items-start">
                          <div>
                            <p className="text-gray-800">iPhone 15 - Safari</p>
                            <p className="text-xs text-gray-500">New York, USA - April 17, 2025 at 7:15 PM</p>
                          </div>
                        </div>
                      </div>
                      <div className="p-4">
                        <div className="flex items-start">
                          <div>
                            <p className="text-gray-800">Windows PC - Firefox</p>
                            <p className="text-xs text-gray-500">New York, USA - April 16, 2025 at 3:45 PM</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 text-right">
                      <button className="text-amber-700 hover:text-amber-800 font-medium">
                        View Full Login History
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Connected Accounts */}
              {activeSection === "connected" && (
                <div className="bg-white rounded-lg shadow-sm p-8">
                  <h2 className="text-3xl font-serif text-gray-800 mb-6">Connected Accounts</h2>
                  <p className="text-gray-600 mb-8">
                    Link your accounts to enable single sign-on and share content between platforms.
                  </p>

                  <div className="space-y-6">
                    {/* Discord */}
                    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center">
                        <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mr-4">
                          <span className="text-indigo-600 text-xl font-bold">D</span>
                        </div>
                        <div>
                          <h4 className="text-lg text-gray-800 font-medium">Discord</h4>
                          <p className="text-sm text-green-600">Connected as DiscordUser#1234</p>
                        </div>
                      </div>
                      <button className="text-red-600 hover:text-red-700">Disconnect</button>
                    </div>

                    {/* Google */}
                    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center">
                        <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mr-4">
                          <span className="text-red-600 text-xl font-bold">G</span>
                        </div>
                        <div>
                          <h4 className="text-lg text-gray-800 font-medium">Google</h4>
                          <p className="text-sm text-green-600">Connected as alex.morgan@gmail.com</p>
                        </div>
                      </div>
                      <button className="text-red-600 hover:text-red-700">Disconnect</button>
                    </div>

                    {/* Twitter */}
                    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center">
                        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                          <span className="text-blue-600 text-xl font-bold">T</span>
                        </div>
                        <div>
                          <h4 className="text-lg text-gray-800 font-medium">Twitter</h4>
                          <p className="text-sm text-gray-500">Not connected</p>
                        </div>
                      </div>
                      <button className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-300 transition-colors">
                        Connect
                      </button>
                    </div>

                    {/* GitHub */}
                    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center">
                        <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mr-4">
                          <span className="text-gray-800 text-xl font-bold">G</span>
                        </div>
                        <div>
                          <h4 className="text-lg text-gray-800 font-medium">GitHub</h4>
                          <p className="text-sm text-gray-500">Not connected</p>
                        </div>
                      </div>
                      <button className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-300 transition-colors">
                        Connect
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Account Management */}
              {activeSection === "management" && (
                <div className="bg-white rounded-lg shadow-sm p-8">
                  <h2 className="text-3xl font-serif text-gray-800 mb-6">Account Management</h2>

                  {/* Data Export */}
                  <div className="mb-10">
                    <h3 className="text-xl font-serif text-gray-800 mb-4">Data Export</h3>
                    <p className="text-gray-600 mb-4">
                      Download a copy of your data including profile information, posts, and activity.
                    </p>
                    <div className="flex flex-wrap gap-4">
                      <button className="bg-amber-700 text-white px-4 py-2 rounded-md hover:bg-amber-800 transition-colors flex items-center">
                        <Download className="h-4 w-4 mr-2" />
                        Export All Data
                      </button>
                      <button className="border border-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-50 transition-colors flex items-center">
                        <File className="h-4 w-4 mr-2" />
                        Export Profile Only
                      </button>
                    </div>
                  </div>

                  {/* Account Visibility */}
                  <div className="border-t border-gray-200 pt-8 mb-10">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-serif text-gray-800">Public Profile</h3>
                        <p className="text-sm text-gray-500 mt-1">Allow others to view your profile and activity</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleToggleChange("publicProfile")}
                        className={`w-12 h-6 rounded-full ${formData.publicProfile ? "bg-amber-700" : "bg-gray-200"} relative`}
                      >
                        <div
                          className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-all ${formData.publicProfile ? "right-1" : "left-1"}`}
                        ></div>
                      </button>
                    </div>

                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-serif text-gray-800">Online Status</h3>
                        <p className="text-sm text-gray-500 mt-1">Show when you're active on the platform</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleToggleChange("onlineStatus")}
                        className={`w-12 h-6 rounded-full ${formData.onlineStatus ? "bg-amber-700" : "bg-gray-200"} relative`}
                      >
                        <div
                          className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-all ${formData.onlineStatus ? "right-1" : "left-1"}`}
                        ></div>
                      </button>
                    </div>
                  </div>

                  {/* Account Deletion */}
                  <div className="border-t border-gray-200 pt-8">
                    <h3 className="text-xl font-serif text-red-600 mb-4">Delete Account</h3>
                    <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
                      <div className="flex">
                        <ExclamationTriangle className="text-red-600 h-5 w-5 mt-1 mr-3" />
                        <div>
                          <p className="text-red-600 font-medium">Warning: This action cannot be undone</p>
                          <p className="text-red-600 text-sm mt-1">
                            Deleting your account will permanently remove all your data, including profile information,
                            posts, and activity history.
                          </p>
                        </div>
                      </div>
                    </div>
                    <button className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors flex items-center">
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete My Account
                    </button>
                  </div>
                </div>
              )}

              {/* Appearance */}
              {activeSection === "appearance" && (
                <div className="bg-white rounded-lg shadow-sm p-8">
                  <h2 className="text-3xl font-serif text-gray-800 mb-6">Appearance</h2>

                  {/* Theme Options */}
                  <div className="mb-8">
                    <h3 className="text-xl font-serif text-gray-800 mb-4">Theme Options</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <button
                        onClick={() => handleThemeChange("light")}
                        className={`p-6 ${theme === "light" ? "border-2 border-amber-700" : "border border-gray-200"} rounded-lg text-center`}
                      >
                        <div className="bg-white border border-gray-200 rounded-md p-4 mb-4">
                          <div className="h-4 w-full bg-amber-700 rounded mb-2"></div>
                          <div className="h-2 w-3/4 bg-gray-200 rounded mb-2"></div>
                          <div className="h-2 w-1/2 bg-gray-200 rounded"></div>
                        </div>
                        <Sun
                          className={`h-6 w-6 mx-auto ${theme === "light" ? "text-amber-700" : "text-gray-400"} mb-2`}
                        />
                        <p className={`text-sm ${theme === "light" ? "text-amber-700 font-medium" : "text-gray-800"}`}>
                          Light Mode
                        </p>
                      </button>

                      <button
                        onClick={() => handleThemeChange("dark")}
                        className={`p-6 ${theme === "dark" ? "border-2 border-amber-700" : "border border-gray-200"} rounded-lg text-center`}
                      >
                        <div className="bg-gray-800 border border-gray-700 rounded-md p-4 mb-4">
                          <div className="h-4 w-full bg-amber-700 rounded mb-2"></div>
                          <div className="h-2 w-3/4 bg-gray-600 rounded mb-2"></div>
                          <div className="h-2 w-1/2 bg-gray-600 rounded"></div>
                        </div>
                        <Moon
                          className={`h-6 w-6 mx-auto ${theme === "dark" ? "text-amber-700" : "text-gray-400"} mb-2`}
                        />
                        <p className={`text-sm ${theme === "dark" ? "text-amber-700 font-medium" : "text-gray-800"}`}>
                          Dark Mode
                        </p>
                      </button>

                      <button
                        onClick={() => handleThemeChange("system")}
                        className={`p-6 ${theme === "system" ? "border-2 border-amber-700" : "border border-gray-200"} rounded-lg text-center`}
                      >
                        <div className="bg-gradient-to-r from-white to-gray-800 border border-gray-200 rounded-md p-4 mb-4">
                          <div className="h-4 w-full bg-amber-700 rounded mb-2"></div>
                          <div className="h-2 w-3/4 bg-gray-400 rounded mb-2"></div>
                          <div className="h-2 w-1/2 bg-gray-400 rounded"></div>
                        </div>
                        <Desktop
                          className={`h-6 w-6 mx-auto ${theme === "system" ? "text-amber-700" : "text-gray-400"} mb-2`}
                        />
                        <p className={`text-sm ${theme === "system" ? "text-amber-700 font-medium" : "text-gray-800"}`}>
                          System Default
                        </p>
                      </button>
                    </div>
                  </div>

                  {/* Font Size */}
                  <div className="border-t border-gray-200 pt-8 mb-8">
                    <h3 className="text-xl font-serif text-gray-800 mb-4">Font Size</h3>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <input
                          type="range"
                          min="1"
                          max="5"
                          defaultValue="3"
                          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                        />
                      </div>
                      <div className="flex justify-between text-sm text-gray-500">
                        <span>Small</span>
                        <span>Default</span>
                        <span>Large</span>
                      </div>
                    </div>
                  </div>

                  {/* Language */}
                  <div className="border-t border-gray-200 pt-8">
                    <h3 className="text-xl font-serif text-gray-800 mb-4">Language</h3>
                    <div className="relative">
                      <div className="flex items-center border border-gray-300 rounded-md">
                        <div className="relative w-full">
                          <select className="appearance-none w-full py-2 pl-4 pr-10 border-none rounded-md focus:ring-2 focus:ring-amber-500 focus:border-transparent text-lg bg-white">
                            <option value="en-US">English (US)</option>
                            <option value="en-GB">English (UK)</option>
                            <option value="es">Español</option>
                            <option value="fr">Français</option>
                            <option value="de">Deutsch</option>
                            <option value="ja">日本語</option>
                            <option value="zh-CN">中文 (简体)</option>
                          </select>
                          <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                            <ChevronDown className="h-4 w-4" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-50 border-t border-gray-200 mt-12">
        <div className="max-w-6xl mx-auto px-6 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h4 className="font-serif text-lg text-gray-800 mb-4">About</h4>
              <p className="text-gray-600 text-base font-sans">
                THE CELLAR GUILD helps you discover and join the perfect Discord communities based on your interests and
                passions.
              </p>
            </div>
            <div>
              <h4 className="font-serif text-lg text-gray-800 mb-4">Categories</h4>
              <ul className="space-y-2 text-gray-600 text-sm font-sans">
                <li>
                  <Link href="#" className="hover:text-gray-800">
                    Gaming
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-gray-800">
                    Technology
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-gray-800">
                    Art & Design
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-serif text-lg text-gray-800 mb-4">Support</h4>
              <ul className="space-y-2 text-gray-600 text-sm font-sans">
                <li>
                  <Link href="#" className="hover:text-gray-800">
                    Discord Guide
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-gray-800">
                    Safety Tips
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-gray-800">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-serif text-lg text-gray-800 mb-4">Connect</h4>
              <div className="flex space-x-4">
                <Link href="#" className="text-gray-600 hover:text-gray-800">
                  <span className="sr-only">Instagram</span>
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fillRule="evenodd"
                      d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z"
                      clipRule="evenodd"
                    />
                  </svg>
                </Link>
                <Link href="#" className="text-gray-600 hover:text-gray-800">
                  <span className="sr-only">Twitter</span>
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                  </svg>
                </Link>
                <Link href="#" className="text-gray-600 hover:text-gray-800">
                  <span className="sr-only">GitHub</span>
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fillRule="evenodd"
                      d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"
                      clipRule="evenodd"
                    />
                  </svg>
                </Link>
              </div>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-gray-200 text-center text-gray-600 text-sm">
            <p>&copy; 2025 THE CELLAR GUILD. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
