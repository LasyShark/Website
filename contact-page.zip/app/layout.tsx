import type React from "react"
import "@/app/globals.css"
import type { Metadata } from "next"
import { Inter, Playfair_Display } from "next/font/google"
import Script from "next/script"

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-sans",
})

const playfair = Playfair_Display({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-serif",
})

export const metadata: Metadata = {
  title: "The Cellar Guild - Contact Us",
  description:
    "Get in touch with The Cellar Guild for any questions about our artisanal products, orders, or crafting traditions.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${inter.variable} ${playfair.variable}`}>
      <head>
        <Script src="https://kit.fontawesome.com/a076d05399.js" crossOrigin="anonymous" strategy="afterInteractive" />
      </head>
      <body className="font-sans text-gray-800">{children}</body>
    </html>
  )
}
