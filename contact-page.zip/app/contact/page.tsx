import ContactHero from "@/components/contact/contact-hero"
import ContactInfo from "@/components/contact/contact-info"
import RecentlyViewed from "@/components/contact/recently-viewed"
import FaqSection from "@/components/contact/faq-section"
import Newsletter from "@/components/shared/newsletter"
import Header from "@/components/shared/header"
import Footer from "@/components/shared/footer"
import Breadcrumb from "@/components/shared/breadcrumb"

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-white text-gray-800 font-sans">
      <Header />
      <Breadcrumb
        items={[
          { label: "Home", href: "/" },
          { label: "Contact Us", href: "/contact", active: true },
        ]}
      />
      <ContactHero />
      <ContactInfo />
      <RecentlyViewed />
      <FaqSection />
      <Newsletter />
      <Footer />
    </div>
  )
}
