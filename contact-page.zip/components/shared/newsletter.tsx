"use client"

import type React from "react"

import { useState } from "react"

export default function Newsletter() {
  const [email, setEmail] = useState("")

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault()
    alert(`Thank you for subscribing with ${email}!`)
    setEmail("")
  }

  return (
    <section className="py-16 bg-white">
      <div className="max-w-2xl mx-auto px-6 text-center">
        <div className="flex justify-center mb-6">
          <div className="w-16 h-1 bg-amber-700"></div>
        </div>
        <h2 className="text-3xl font-serif font-bold mb-4 text-gray-800">Join The Guild</h2>
        <p className="text-xl font-sans text-gray-600 mb-8">
          Subscribe to receive updates on new collections, special offers, and crafting inspiration.
        </p>
        <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-4 justify-center">
          <input
            type="email"
            placeholder="Your email address"
            className="px-4 py-3 text-lg border-2 border-gray-300 focus:border-amber-700 focus:ring-2 focus:ring-amber-100 outline-none rounded-sm flex-grow transition-all duration-300"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            aria-label="Email address"
          />
          <button
            type="submit"
            className="bg-amber-700 hover:bg-amber-800 text-white text-base px-6 py-3 rounded-sm transition-colors duration-300 cursor-pointer rounded-button whitespace-nowrap"
          >
            Subscribe
          </button>
        </form>
        <p className="text-xs text-gray-500 mt-4">
          By subscribing, you agree to our Privacy Policy and consent to receive updates from The Cellar Guild.
        </p>
      </div>
    </section>
  )
}
