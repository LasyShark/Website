"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"

export default function Header() {
  const [isCartOpen, setIsCartOpen] = useState(false)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isLanguageMenuOpen, setIsLanguageMenuOpen] = useState(false)

  const toggleCart = () => {
    setIsCartOpen(!isCartOpen)
  }

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className="bg-white py-4 px-6 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="lg:hidden">
          <button
            onClick={toggleMenu}
            className="text-gray-800 hover:text-amber-700 cursor-pointer rounded-button whitespace-nowrap"
            aria-label="Toggle menu"
          >
            <i className="fas fa-bars text-xl"></i>
          </button>
        </div>

        <nav
          className={`lg:flex items-center space-x-8 ${isMenuOpen ? "block absolute top-16 left-0 right-0 bg-white p-4 shadow-md" : "hidden"} lg:static lg:shadow-none lg:p-0 lg:bg-transparent`}
        >
          <Link
            href="#shop"
            className="text-lg font-medium font-serif text-gray-800 hover:text-amber-700 tracking-wide cursor-pointer"
          >
            Shop
          </Link>
          <Link
            href="#about"
            className="text-lg font-medium font-serif text-gray-800 hover:text-amber-700 tracking-wide cursor-pointer"
          >
            About
          </Link>
          <Link
            href="/contact"
            className="text-lg font-medium font-serif text-amber-700 tracking-wide cursor-pointer hover:text-amber-800"
          >
            Contact
          </Link>
        </nav>

        <div className="flex items-center justify-center flex-grow lg:flex-grow-0">
          <Link href="/" className="flex items-center space-x-2 cursor-pointer">
            <Image
              src="https://static.readdy.ai/image/78528fc9b9d09b4177519be0ab8007c6/7d65ab9ce55ac25c5de55d3ff06a128b.png"
              alt="The Cellar Guild Logo"
              width={40}
              height={40}
              className="h-10 w-auto"
            />
            <span className="text-2xl font-bold font-serif tracking-widest text-gray-800">THE CELLAR GUILD</span>
          </Link>
        </div>

        <div className="flex items-center space-x-4">
          <div className="relative group" onMouseLeave={() => setIsLanguageMenuOpen(false)}>
            <button
              className="flex items-center space-x-1 text-gray-700 hover:text-gray-900 rounded-button whitespace-nowrap"
              onMouseEnter={() => setIsLanguageMenuOpen(true)}
              aria-label="Select language"
            >
              <i className="fas fa-globe text-xl"></i>
              <i className="fas fa-chevron-down text-xs"></i>
            </button>
            <div
              className={`absolute right-0 top-full mt-2 w-48 bg-white shadow-lg rounded-sm transition-opacity duration-200 ${isLanguageMenuOpen ? "opacity-100 visible" : "opacity-0 invisible"}`}
              onMouseEnter={() => setIsLanguageMenuOpen(true)}
            >
              <div className="py-2">
                <button className="w-full px-4 py-2 text-left hover:bg-gray-100 text-sm text-gray-800">English</button>
                <button className="w-full px-4 py-2 text-left hover:bg-gray-100 text-sm text-gray-800">Français</button>
                <button className="w-full px-4 py-2 text-left hover:bg-gray-100 text-sm text-gray-800">Deutsch</button>
                <button className="w-full px-4 py-2 text-left hover:bg-gray-100 text-sm text-gray-800">Español</button>
                <button className="w-full px-4 py-2 text-left hover:bg-gray-100 text-sm text-gray-800">Italiano</button>
              </div>
            </div>
          </div>

          <button
            onClick={toggleCart}
            className="relative text-gray-800 hover:text-amber-700 cursor-pointer rounded-button whitespace-nowrap"
            aria-label="Shopping cart"
          >
            <i className="fas fa-shopping-cart text-xl"></i>
            <span className="absolute -top-2 -right-2 bg-amber-700 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
              0
            </span>
          </button>
        </div>
      </div>
    </header>
  )
}
