import Link from "next/link"

export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-200 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div>
            <h3 className="text-2xl font-serif font-bold tracking-widest mb-4 text-gray-800">THE CELLAR GUILD</h3>
            <p className="text-gray-600 mb-4">
              Curated collections of premium hobbyist materials for creative enthusiasts.
            </p>
            <div className="flex space-x-4">
              <a
                href="#"
                className="text-gray-600 hover:text-amber-700 transition-colors duration-300 cursor-pointer"
                aria-label="Instagram"
              >
                <i className="fab fa-instagram text-xl"></i>
              </a>
              <a
                href="#"
                className="text-gray-600 hover:text-amber-700 transition-colors duration-300 cursor-pointer"
                aria-label="Facebook"
              >
                <i className="fab fa-facebook text-xl"></i>
              </a>
              <a
                href="#"
                className="text-gray-600 hover:text-amber-700 transition-colors duration-300 cursor-pointer"
                aria-label="Pinterest"
              >
                <i className="fab fa-pinterest text-xl"></i>
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-serif font-bold tracking-wide mb-4 text-gray-800">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/about"
                  className="text-gray-600 hover:text-amber-700 transition-colors duration-300 cursor-pointer"
                >
                  About Us
                </Link>
              </li>
              <li>
                <Link
                  href="/shop"
                  className="text-gray-600 hover:text-amber-700 transition-colors duration-300 cursor-pointer"
                >
                  Shop All
                </Link>
              </li>
              <li>
                <Link
                  href="/faq"
                  className="text-gray-600 hover:text-amber-700 transition-colors duration-300 cursor-pointer"
                >
                  FAQ
                </Link>
              </li>
              <li>
                <Link
                  href="/shipping"
                  className="text-gray-600 hover:text-amber-700 transition-colors duration-300 cursor-pointer"
                >
                  Shipping & Returns
                </Link>
              </li>
              <li>
                <Link
                  href="/contact"
                  className="text-gray-600 hover:text-amber-700 transition-colors duration-300 cursor-pointer"
                >
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-serif font-bold mb-4 text-gray-800">Contact</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <i className="fas fa-map-marker-alt mt-1 mr-2 text-amber-700"></i>
                <span className="text-gray-600">123 Craft Lane, Artisan District</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-envelope mt-1 mr-2 text-amber-700"></i>
                <span className="text-gray-600">hello@cellarguild.com</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-phone mt-1 mr-2 text-amber-700"></i>
                <span className="text-gray-600">+1 (234) 567-8910</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-200 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-500 mb-4 md:mb-0">© 2025 The Cellar Guild. All rights reserved.</p>
          <div className="flex space-x-4">
            <Link
              href="/privacy"
              className="text-sm text-gray-500 hover:text-amber-700 transition-colors duration-300 cursor-pointer"
            >
              Privacy Policy
            </Link>
            <Link
              href="/terms"
              className="text-sm text-gray-500 hover:text-amber-700 transition-colors duration-300 cursor-pointer"
            >
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
