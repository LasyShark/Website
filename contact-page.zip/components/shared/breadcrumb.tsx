import Link from "next/link"

interface BreadcrumbItem {
  label: string
  href: string
  active?: boolean
}

interface BreadcrumbProps {
  items: BreadcrumbItem[]
}

export default function Breadcrumb({ items }: BreadcrumbProps) {
  return (
    <div className="bg-gray-50 py-3">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center text-sm text-gray-600">
          {items.map((item, index) => (
            <div key={index} className="flex items-center">
              {index > 0 && <span className="mx-2 text-gray-500">/</span>}
              {item.active ? (
                <span className="text-amber-700">{item.label}</span>
              ) : (
                <Link href={item.href} className="hover:text-amber-700 cursor-pointer">
                  {item.label}
                </Link>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
