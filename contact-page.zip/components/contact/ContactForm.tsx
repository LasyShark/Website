"use client"

import type React from "react"

import { useState } from "react"

interface FormData {
  name: string
  email: string
  subject: string
  message: string
}

interface FormErrors {
  name: string
  email: string
  message: string
}

export default function ContactForm() {
  const [formData, setFormData] = useState<FormData>({
    name: "",
    email: "",
    subject: "General Inquiry",
    message: "",
  })

  const [formErrors, setFormErrors] = useState<FormErrors>({
    name: "",
    email: "",
    message: "",
  })

  const [formSubmitted, setFormSubmitted] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })

    // Clear error when user types
    if (formErrors[name as keyof typeof formErrors]) {
      setFormErrors({
        ...formErrors,
        [name]: "",
      })
    }
  }

  const validateForm = () => {
    const errors = {
      name: "",
      email: "",
      message: "",
    }
    let isValid = true

    if (!formData.name.trim()) {
      errors.name = "Name is required"
      isValid = false
    }

    if (!formData.email.trim()) {
      errors.email = "Email is required"
      isValid = false
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = "Email is invalid"
      isValid = false
    }

    if (!formData.message.trim()) {
      errors.message = "Message is required"
      isValid = false
    }

    setFormErrors(errors)
    return isValid
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (validateForm()) {
      // Form submission logic would go here
      setFormSubmitted(true)
      setFormData({
        name: "",
        email: "",
        subject: "General Inquiry",
        message: "",
      })

      // Reset form after 5 seconds
      setTimeout(() => {
        setFormSubmitted(false)
      }, 5000)
    }
  }

  return (
    <div className="p-8">
      <h2 className="text-3xl font-serif font-bold mb-6 text-gray-800">Send Us a Message</h2>
      {formSubmitted ? (
        <div className="bg-green-50 border border-green-200 text-green-600 p-4 rounded-sm mb-6">
          <div className="flex items-center mb-2">
            <i className="fas fa-check-circle text-green-600 mr-2"></i>
            <span className="font-medium">Message Sent Successfully!</span>
          </div>
          <p>Thank you for contacting us. We'll get back to you as soon as possible.</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="name" className="block text-base font-medium text-gray-800 mb-1">
              Name
            </label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              className={`w-full px-4 py-2 text-lg border ${formErrors.name ? "border-red-600" : "border-gray-300"} rounded-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent`}
              placeholder="Your name"
            />
            {formErrors.name && <p className="mt-1 text-sm text-red-600">{formErrors.name}</p>}
          </div>

          <div className="mb-4">
            <label htmlFor="email" className="block text-base font-medium text-gray-800 mb-1">
              Email
            </label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              className={`w-full px-4 py-2 text-lg border ${formErrors.email ? "border-red-600" : "border-gray-300"} rounded-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent`}
              placeholder="Your email address"
            />
            {formErrors.email && <p className="mt-1 text-sm text-red-600">{formErrors.email}</p>}
          </div>

          <div className="mb-4">
            <label htmlFor="subject" className="block text-base font-medium text-gray-800 mb-1">
              Subject
            </label>
            <div className="relative">
              <select
                id="subject"
                name="subject"
                value={formData.subject}
                onChange={handleInputChange}
                className="w-full px-4 py-2 text-lg border border-gray-300 rounded-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent appearance-none"
              >
                <option value="General Inquiry">General Inquiry</option>
                <option value="Product Question">Product Question</option>
                <option value="Order Status">Order Status</option>
                <option value="Return Request">Return Request</option>
                <option value="Wholesale Inquiry">Wholesale Inquiry</option>
              </select>
              <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                <i className="fas fa-chevron-down text-gray-400"></i>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <label htmlFor="message" className="block text-base font-medium text-gray-800 mb-1">
              Message
            </label>
            <textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleInputChange}
              rows={5}
              className={`w-full px-4 py-2 text-lg border ${formErrors.message ? "border-red-600" : "border-gray-300"} rounded-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent`}
              placeholder="How can we help you?"
            ></textarea>
            {formErrors.message && <p className="mt-1 text-sm text-red-600">{formErrors.message}</p>}
          </div>

          <button
            type="submit"
            className="bg-amber-700 hover:bg-amber-800 text-white px-6 py-3 text-base rounded-sm transition-all duration-300 cursor-pointer rounded-button whitespace-nowrap hover:shadow-lg transform hover:-translate-y-0.5"
          >
            Send Message
          </button>
        </form>
      )}
    </div>
  )
}
