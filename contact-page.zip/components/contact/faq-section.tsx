"use client"

import { useState } from "react"
import Link from "next/link"

const faqItems = [
  {
    question: "What types of products does The Cellar Guild offer?",
    answer:
      "The Cellar Guild specializes in artisanal hobbyist materials, including craft supplies, board games, puzzles, books, candles, textile arts, divination tools, and herbal crafts. All our products are carefully curated for quality and uniqueness.",
  },
  {
    question: "Do you ship internationally?",
    answer:
      "Yes, we ship to most countries worldwide. International shipping rates and delivery times vary depending on location. Please note that customers are responsible for any customs fees or import taxes that may apply to international orders.",
  },
  {
    question: "What is your return policy?",
    answer:
      "We accept returns within 30 days of delivery for items in their original condition. Please contact our customer service team to initiate a return. Custom or personalized items cannot be returned unless they arrive damaged or defective.",
  },
  {
    question: "How can I track my order?",
    answer:
      "Once your order ships, you'll receive a confirmation email with tracking information. You can use this tracking number on our website or the carrier's website to monitor your package's journey. For any issues with tracking, please contact our customer support team.",
  },
  {
    question: "Do you offer gift wrapping services?",
    answer:
      "Yes! We offer premium gift wrapping services for all our products. During checkout, you can select the gift wrap option and even include a personalized message. Our elegant wrapping adds a special touch to your gifts.",
  },
]

export default function FaqSection() {
  const [activeAccordion, setActiveAccordion] = useState<number | null>(null)

  const toggleAccordion = (index: number) => {
    setActiveAccordion(activeAccordion === index ? null : index)
  }

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-3xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-serif font-bold mb-4 text-gray-800">Frequently Asked Questions</h2>
          <p className="text-xl font-sans text-gray-600">
            Find answers to common questions about our products and services.
          </p>
        </div>

        <div className="space-y-4">
          {faqItems.slice(0, 4).map((item, index) => (
            <div key={index} className="bg-white rounded-sm shadow-md overflow-hidden">
              <button
                className="w-full px-6 py-4 text-left flex justify-between items-center focus:outline-none cursor-pointer rounded-button whitespace-nowrap"
                onClick={() => toggleAccordion(index)}
                aria-expanded={activeAccordion === index}
              >
                <span className="font-medium text-gray-800">{item.question}</span>
                <i
                  className={`fas ${activeAccordion === index ? "fa-chevron-up" : "fa-chevron-down"} text-amber-700 transition-transform duration-300`}
                ></i>
              </button>
              <div
                className={`px-6 overflow-hidden transition-all duration-300 ${activeAccordion === index ? "max-h-96 py-4" : "max-h-0 py-0"}`}
                aria-hidden={activeAccordion !== index}
              >
                <p className="text-gray-600">{item.answer}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-10">
          <p className="text-gray-600 mb-4">Still have questions?</p>
          <Link
            href="/faq"
            className="inline-flex items-center text-lg font-medium text-amber-700 hover:text-amber-800 cursor-pointer"
          >
            <span>View our complete FAQ</span>
            <i className="fas fa-arrow-right ml-2"></i>
          </Link>
        </div>
      </div>
    </section>
  )
}
