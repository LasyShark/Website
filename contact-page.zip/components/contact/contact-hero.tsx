export default function ContactHero() {
  return (
    <section className="relative py-16 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-serif font-bold mb-4 text-gray-800">Contact Us</h1>
          <p className="text-xl font-sans text-gray-600 max-w-2xl mx-auto">
            We're here to help with any questions about our products, orders, or crafting traditions. Reach out to us
            and we'll respond as soon as possible.
          </p>
        </div>
      </div>
    </section>
  )
}
