"use client"

import { Swiper, SwiperSlide } from "swiper/react"
import { Pagination, Autoplay } from "swiper/modules"
import "swiper/css"
import "swiper/css/pagination"
import Image from "next/image"

const products = [
  {
    id: 1,
    name: "Artisan Leather Journal",
    price: "$45.00",
    image:
      "https://readdy.ai/api/search-image?query=A%20beautiful%20handcrafted%20leather%20journal%20with%20intricate%20embossing%20and%20gold%20accents%2C%20photographed%20on%20a%20clean%20white%20marble%20surface%20with%20soft%20natural%20lighting%20and%20minimal%20styling&width=400&height=400&seq=1&orientation=squarish",
  },
  {
    id: 2,
    name: "Calligraphy Master Set",
    price: "$75.00",
    image:
      "https://readdy.ai/api/search-image?query=A%20set%20of%20premium%20wooden%20calligraphy%20pens%20with%20brass%20details%20and%20various%20nibs%2C%20arranged%20on%20a%20clean%20white%20marble%20surface%20with%20soft%20natural%20lighting%20and%20minimal%20styling&width=400&height=400&seq=2&orientation=squarish",
  },
  {
    id: 3,
    name: "Botanical Candle Set",
    price: "$35.00",
    image:
      "https://readdy.ai/api/search-image?query=A%20collection%20of%20handmade%20soy%20wax%20candles%20in%20amber%20glass%20jars%20with%20botanical%20decorations%2C%20photographed%20on%20a%20clean%20white%20marble%20surface%20with%20soft%20natural%20lighting%20and%20minimal%20styling&width=400&height=400&seq=3&orientation=squarish",
  },
  {
    id: 4,
    name: "Artisan Chess Set",
    price: "$129.00",
    image:
      "https://readdy.ai/api/search-image?query=A%20premium%20wooden%20chess%20set%20with%20hand-carved%20pieces%20and%20inlaid%20board%2C%20photographed%20on%20a%20clean%20white%20marble%20surface%20with%20soft%20natural%20lighting%20and%20minimal%20styling&width=400&height=400&seq=4&orientation=squarish",
  },
  {
    id: 5,
    name: "Pottery Tool Kit",
    price: "$89.00",
    image:
      "https://readdy.ai/api/search-image?query=A%20set%20of%20handmade%20ceramic%20pottery%20tools%20and%20brushes%20with%20wooden%20handles%2C%20arranged%20on%20a%20clean%20white%20marble%20surface%20with%20soft%20natural%20lighting%20and%20minimal%20styling&width=400&height=400&seq=5&orientation=squarish",
  },
]

export default function RecentlyViewed() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-serif font-bold mb-4 text-gray-800">Others Also Viewed</h2>
          <p className="text-xl font-sans text-gray-600 max-w-2xl mx-auto">
            Discover what other craft enthusiasts are exploring
          </p>
        </div>

        <div className="relative">
          <Swiper
            modules={[Pagination, Autoplay]}
            spaceBetween={24}
            slidesPerView={1}
            pagination={{ clickable: true }}
            autoplay={{ delay: 3000 }}
            breakpoints={{
              640: { slidesPerView: 2 },
              768: { slidesPerView: 3 },
              1024: { slidesPerView: 4 },
            }}
            className="pb-12"
          >
            {products.map((product) => (
              <SwiperSlide key={product.id}>
                <div className="bg-white rounded-sm shadow-md overflow-hidden hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                  <div className="aspect-w-1 aspect-h-1 w-full overflow-hidden">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={400}
                      height={400}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-4">
                    <h3 className="text-lg font-medium mb-2 text-gray-800">{product.name}</h3>
                    <p className="text-amber-700 font-medium">{product.price}</p>
                  </div>
                </div>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </div>
    </section>
  )
}
