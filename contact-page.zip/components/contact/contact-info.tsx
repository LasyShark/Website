import ContactForm from "./ContactForm"

export default function ContactInfo() {
  return (
    <section className="relative pb-16 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white p-6 rounded-sm shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 flex flex-col items-center text-center">
            <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mb-4">
              <i className="fas fa-map-marker-alt text-amber-700 text-xl"></i>
            </div>
            <h3 className="text-xl font-medium mb-2 text-gray-800">Visit Us</h3>
            <p className="text-gray-600">123 Craft Lane</p>
            <p className="text-gray-600">Artisan District</p>
          </div>

          <div className="bg-white p-6 rounded-sm shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 flex flex-col items-center text-center">
            <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mb-4">
              <i className="fas fa-envelope text-amber-700 text-xl"></i>
            </div>
            <h3 className="text-xl font-medium mb-2 text-gray-800">Email Us</h3>
            <p className="text-gray-600">hello@cellarguild.com</p>
            <p className="text-gray-600">support@cellarguild.com</p>
          </div>

          <div className="bg-white p-6 rounded-sm shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 flex flex-col items-center text-center">
            <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mb-4">
              <i className="fab fa-whatsapp text-amber-700 text-xl"></i>
            </div>
            <h3 className="text-xl font-medium mb-2 text-gray-800">WhatsApp Us</h3>
            <p className="text-gray-600">+1 (234) 567-8910</p>
            <p className="text-gray-600">Available 24/7</p>
          </div>
        </div>

        <div className="bg-white rounded-sm shadow-md overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <ContactForm />
            <div className="h-full min-h-[400px] lg:min-h-0 relative">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12450.475672089725!2d-76.94894284999999!3d38.8663683!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89b7a97c2bd0683d%3A0x7f13c8c18ea2e96f!2sTemple%20Hills%2C%20MD!5e0!3m2!1sen!2sus!4v1650154862224!5m2!1sen!2sus"
                className="absolute inset-0 w-full h-full border-0"
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="The Cellar Guild Location"
              ></iframe>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
